SystemeGestionTresorsCaches = {}

function SystemeGestionTresorsCaches:DiscoverTreasure(player, treasureLocation)
    print(player .. " discovers a hidden treasure at " .. treasureLocation)
end

function SystemeGestionTresorsCaches:CollectTreasure(player, treasureType)
    print(player .. " collects treasure: " .. treasureType)
end

return SystemeGestionTresorsCaches
