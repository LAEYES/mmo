SystemeGestionFaune = {}

function SystemeGestionFaune:EncounterAnimal(player, animalType)
    print(player .. " encounters a wild animal: " .. animalType)
end

function SystemeGestionFaune:HuntAnimal(player, animalType)
    print(player .. " hunts the animal: " .. animalType)
end

return SystemeGestionFaune
