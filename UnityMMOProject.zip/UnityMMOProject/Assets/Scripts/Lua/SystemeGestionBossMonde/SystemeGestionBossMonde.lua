SystemeGestionBossMonde = {}

function SystemeGestionBossMonde:SummonWorldBoss(bossName, location)
    print("The world boss " .. bossName .. " has appeared at " .. location)
end

function SystemeGestionBossMonde:DefeatWorldBoss(playerGroup, bossName)
    print("The group led by " .. playerGroup[1] .. " has defeated the world boss: " .. bossName)
end

return SystemeGestionBossMonde
