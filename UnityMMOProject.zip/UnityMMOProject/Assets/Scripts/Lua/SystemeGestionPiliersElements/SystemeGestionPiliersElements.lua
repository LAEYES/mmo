SystemeGestionPiliersElements = {}

function SystemeGestionPiliersElements:SummonElementalPillar(player, elementType)
    print(player .. " summons the elemental pillar of: " .. elementType)
end

function SystemeGestionPiliersElements:UsePillarPower(player, elementType)
    print(player .. " uses the power of the elemental pillar of: " .. elementType)
end

return SystemeGestionPiliersElements
