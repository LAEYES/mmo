SystemeGestionVortexEnergie = {}

function SystemeGestionVortexEnergie:AccessEnergyVortex(player, vortexName)
    print(player .. " accesses the energy vortex: " .. vortexName)
end

function SystemeGestionVortexEnergie:UseVortexPower(player, powerType)
    print(player .. " uses the vortex power: " .. powerType)
end

return SystemeGestionVortexEnergie
