SystemeGestionEspritsAnciens = {}

function SystemeGestionEspritsAnciens:SummonAncientSpirit(player, spiritName)
    print(player .. " summons the ancient spirit: " .. spiritName)
end

function SystemeGestionEspritsAnciens:ReceiveSpiritBlessing(player, spiritName, blessing)
    print(player .. " receives a blessing from the spirit " .. spiritName .. ": " .. blessing)
end

return SystemeGestionEspritsAnciens
