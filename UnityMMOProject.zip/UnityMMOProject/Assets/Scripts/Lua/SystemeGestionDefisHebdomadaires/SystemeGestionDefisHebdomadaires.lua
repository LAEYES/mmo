SystemeGestionDefisHebdomadaires = {}

function SystemeGestionDefisHebdomadaires:StartWeeklyChallenge(player, challengeName)
    print(player .. " starts the weekly challenge: " .. challengeName)
end

function SystemeGestionDefisHebdomadaires:CompleteWeeklyChallenge(player, challengeName)
    print(player .. " completes the weekly challenge: " .. challengeName)
end

return SystemeGestionDefisHebdomadaires
