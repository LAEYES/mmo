SystemeQueteDynamique = {}

function SystemeQueteDynamique:CreateDynamicQuest(player, difficulty)
    local quest = "Retrieve the ancient artifact"
    print(player .. " has received a dynamic quest: " .. quest .. " (Difficulty: " .. difficulty .. ")")
end

function SystemeQueteDynamique:CompleteQuest(player, quest)
    print(player .. " has completed the quest: " .. quest)
end

return SystemeQueteDynamique
