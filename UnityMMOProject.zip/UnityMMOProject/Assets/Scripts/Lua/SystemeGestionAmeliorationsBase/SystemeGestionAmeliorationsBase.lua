SystemeGestionAmeliorationsBase = {}

function SystemeGestionAmeliorationsBase:UpgradeBase(player, upgradeType)
    print(player .. " upgrades their base with: " .. upgradeType)
end

function SystemeGestionAmeliorationsBase:UnlockFacility(player, facilityName)
    print(player .. " unlocks the facility: " .. facilityName)
end

return SystemeGestionAmeliorationsBase
