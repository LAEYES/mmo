SystemeRaidDonjon = {}

function SystemeRaidDonjon:CreateRaid(raidName, players)
    print("Creating raid: " .. raidName)
    for _, player in ipairs(players) do
        print(player .. " joins the raid.")
    end
end

function SystemeRaidDonjon:StartRaid(raidName)
    print("Starting raid: " .. raidName)
end

function SystemeRaidDonjon:CompleteRaid(raidName, players)
    print("Raid " .. raidName .. " completed by: " .. table.concat(players, ", "))
end

return SystemeRaidDonjon
