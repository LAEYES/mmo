SystemeGestionOrbesStellaires = {}

function SystemeGestionOrbesStellaires:FindStellarOrb(player, orbName)
    print(player .. " finds a stellar orb: " .. orbName)
end

function SystemeGestionOrbesStellaires:UseOrbPower(player, powerType)
    print(player .. " uses the power of the stellar orb for " .. powerType)
end

return SystemeGestionOrbesStellaires
