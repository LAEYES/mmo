SystemeGestionRunesAnciennes = {}

function SystemeGestionRunesAnciennes:DiscoverAncientRune(player, runeName)
    print(player .. " discovers an ancient rune: " .. runeName)
end

function SystemeGestionRunesAnciennes:ActivateRunePower(player, runeName)
    print(player .. " activates the power of the rune: " .. runeName)
end

return SystemeGestionRunesAnciennes
