SystemeGestionReliquesDivines = {}

function SystemeGestionReliquesDivines:DiscoverDivineRelic(player, relicName)
    print(player .. " discovers a divine relic: " .. relicName)
end

function SystemeGestionReliquesDivines:UseDivineRelic(player, relicName)
    print(player .. " uses the divine relic: " .. relicName)
end

return SystemeGestionReliquesDivines
