SystemeGestionEnvironnementInteractif = {}

function SystemeGestionEnvironnementInteractif:InteractWithObject(player, objectName)
    print(player .. " interacts with " .. objectName)
end

function SystemeGestionEnvironnementInteractif:OpenTreasure(player, treasure)
    print(player .. " opens a treasure: " .. treasure)
end

return SystemeGestionEnvironnementInteractif
