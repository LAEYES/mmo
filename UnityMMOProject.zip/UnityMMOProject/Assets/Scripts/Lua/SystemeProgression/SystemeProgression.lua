SystemeProgression = {}

function SystemeProgression:GainExperience(player, amount)
    print(player .. " gains " .. amount .. " experience points")
end

function SystemeProgression:LevelUp(player)
    print(player .. " levels up!")
end

return SystemeProgression
