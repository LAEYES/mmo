SystemeGestionEnchantementObjets = {}

function SystemeGestionEnchantementObjets:EnchantItem(player, item, enchantment)
    print(player .. " enchants " .. item .. " with " .. enchantment)
end

function SystemeGestionEnchantementObjets:RemoveEnchantment(player, item)
    print(player .. " removes the enchantment from " .. item)
end

return SystemeGestionEnchantementObjets
