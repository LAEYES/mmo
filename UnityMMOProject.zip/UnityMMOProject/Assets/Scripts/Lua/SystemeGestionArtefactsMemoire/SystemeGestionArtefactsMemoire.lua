SystemeGestionArtefactsMemoire = {}

function SystemeGestionArtefactsMemoire:DiscoverMemoryArtifact(player, artifactName)
    print(player .. " discovers a memory artifact: " .. artifactName)
end

function SystemeGestionArtefactsMemoire:ReliveMemory(player, memoryName)
    print(player .. " relives the memory of: " .. memoryName)
end

return SystemeGestionArtefactsMemoire
