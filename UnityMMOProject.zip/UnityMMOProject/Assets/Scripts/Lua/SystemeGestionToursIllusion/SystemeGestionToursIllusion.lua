SystemeGestionToursIllusion = {}

function SystemeGestionToursIllusion:EnterIllusionTower(player, towerName)
    print(player .. " enters the illusion tower: " .. towerName)
end

function SystemeGestionToursIllusion:NavigateIllusion(player, direction)
    print(player .. " navigates the illusion maze in the direction: " .. direction)
end

return SystemeGestionToursIllusion
