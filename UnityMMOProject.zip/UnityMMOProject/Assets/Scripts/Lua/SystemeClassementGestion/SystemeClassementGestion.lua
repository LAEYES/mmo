SystemeClassementGestion = {}

function SystemeClassementGestion:AddPlayerToLeaderboard(player, score)
    print(player .. " has achieved a score of " .. score .. " and is added to the leaderboard.")
end

function SystemeClassementGestion:DisplayLeaderboard()
    print("Displaying the current leaderboard...")
    local leaderboard = {
        {player = "Player1", score = 3000},
        {player = "Player2", score = 2500}
    }
    for i, entry in ipairs(leaderboard) do
        print(i .. ". " .. entry.player .. " - Score: " .. entry.score)
    end
end

return SystemeClassementGestion
