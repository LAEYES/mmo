SystemeEvenementsMondiaux = {}

function SystemeEvenementsMondiaux:StartEvent(eventName)
    print("World event '" .. eventName .. "' has started!")
end

function SystemeEvenementsMondiaux:EndEvent(eventName)
    print("World event '" .. eventName .. "' has ended.")
end

return SystemeEvenementsMondiaux
