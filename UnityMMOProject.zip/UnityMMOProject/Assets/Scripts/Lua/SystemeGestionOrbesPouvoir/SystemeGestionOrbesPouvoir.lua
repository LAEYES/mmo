SystemeGestionOrbesPouvoir = {}

function SystemeGestionOrbesPouvoir:CollectPowerOrb(player, orbType)
    print(player .. " collects a power orb of type: " .. orbType)
end

function SystemeGestionOrbesPouvoir:UsePowerOrb(player, orbType)
    print(player .. " uses the power orb of type: " .. orbType)
end

return SystemeGestionOrbesPouvoir
