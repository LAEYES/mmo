SystemeGestionArtefactsMythiques = {}

function SystemeGestionArtefactsMythiques:DiscoverMythicalArtifact(player, artifactName)
    print(player .. " has discovered a mythical artifact: " .. artifactName)
end

function SystemeGestionArtefactsMythiques:UseMythicalArtifact(player, artifactName)
    print(player .. " uses the mythical artifact: " .. artifactName)
end

return SystemeGestionArtefactsMythiques
