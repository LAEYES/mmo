GestionnaireReseau = {}

function GestionnaireReseau:ConnectPlayer(player)
    print(player .. " connects to the network.")
end

function GestionnaireReseau:DisconnectPlayer(player)
    print(player .. " disconnects from the network.")
end

function GestionnaireReseau:SyncPlayerData(player)
    print("Syncing data for " .. player)
end

return GestionnaireReseau
