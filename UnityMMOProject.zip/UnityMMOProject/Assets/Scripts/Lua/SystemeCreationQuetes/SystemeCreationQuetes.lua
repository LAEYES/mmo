SystemeCreationQuetes = {}

function SystemeCreationQuetes:CreateQuest(questName, objectives)
    print("Creating quest: " .. questName)
    for _, objective in ipairs(objectives) do
        print("Objective: " .. objective)
    end
end

function SystemeCreationQuetes:AssignQuest(player, questName)
    print(player .. " is assigned the quest: " .. questName)
end

return SystemeCreationQuetes
