SystemeGestionOmbresEternelles = {}

function SystemeGestionOmbresEternelles:SummonEternalShadow(player, shadowName)
    print(player .. " summons the eternal shadow: " .. shadowName)
end

function SystemeGestionOmbresEternelles:ControlShadow(player, shadowName)
    print(player .. " controls the shadow: " .. shadowName)
end

return SystemeGestionOmbresEternelles
