-- Game settings
GameSettings = {
    difficulty = 'Normal',
    graphics = 'High'
}

function GameSettings:SetDifficulty(level)
    self.difficulty = level
    print('Difficulty set to ' .. level)
end

function GameSettings:SetGraphics(level)
    self.graphics = level
    print('Graphics set to ' .. level)
end
