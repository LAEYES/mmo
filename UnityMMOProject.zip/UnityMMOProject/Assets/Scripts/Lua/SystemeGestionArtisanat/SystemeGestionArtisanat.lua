SystemeGestionArtisanat = {}

function SystemeGestionArtisanat:CraftItem(player, itemName, resources)
    print(player .. " crafts " .. itemName .. " using resources: " .. table.concat(resources, ", "))
end

function SystemeGestionArtisanat:GatherResource(player, resource)
    print(player .. " gathers " .. resource)
end

return SystemeGestionArtisanat
