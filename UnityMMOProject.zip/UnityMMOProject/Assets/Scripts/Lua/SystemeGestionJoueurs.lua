SystemeGestionJoueurs = {}

function SystemeGestionJoueurs:CreateCharacter(player, name, class, race)
    print("Creating character for player: " .. player .. ", Name: " .. name .. ", Class: " .. class .. ", Race: " .. race)
end

function SystemeGestionJoueurs:GainExperience(player, amount)
    print(player .. " gains " .. amount .. " experience points.")
end

function SystemeGestionJoueurs:AddToInventory(player, item)
    print(player .. " adds item to inventory: " .. item)
end

return SystemeGestionJoueurs
