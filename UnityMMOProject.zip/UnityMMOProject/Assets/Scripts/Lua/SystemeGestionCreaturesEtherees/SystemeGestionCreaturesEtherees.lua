SystemeGestionCreaturesEtherees = {}

function SystemeGestionCreaturesEtherees:SummonEtherealCreature(player, creatureName)
    print(player .. " summons the ethereal creature: " .. creatureName)
end

function SystemeGestionCreaturesEtherees:CaptureEtherealCreature(player, creatureName)
    print(player .. " captures the ethereal creature: " .. creatureName)
end

return SystemeGestionCreaturesEtherees
