SystemeGestionTemplesSacres = {}

function SystemeGestionTemplesSacres:EnterSacredTemple(player, templeName)
    print(player .. " enters the sacred temple: " .. templeName)
end

function SystemeGestionTemplesSacres:ReceiveTempleBlessing(player, templeName, blessing)
    print(player .. " receives a blessing from the sacred temple: " .. templeName .. " - " .. blessing)
end

return SystemeGestionTemplesSacres
