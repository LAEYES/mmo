SystemeGestionArmesLegendaires = {}

function SystemeGestionArmesLegendaires:ForgeLegendaryWeapon(player, weaponName)
    print(player .. " forges the legendary weapon: " .. weaponName)
end

function SystemeGestionArmesLegendaires:UseLegendaryWeapon(player, weaponName)
    print(player .. " wields the legendary weapon: " .. weaponName)
end

return SystemeGestionArmesLegendaires
