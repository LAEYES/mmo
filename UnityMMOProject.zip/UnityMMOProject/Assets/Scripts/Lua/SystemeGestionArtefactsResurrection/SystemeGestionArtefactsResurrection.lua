SystemeGestionArtefactsResurrection = {}

function SystemeGestionArtefactsResurrection:FindResurrectionArtifact(player, artifactName)
    print(player .. " finds a resurrection artifact: " .. artifactName)
end

function SystemeGestionArtefactsResurrection:UseResurrectionPower(player, target)
    print(player .. " uses the resurrection power on: " .. target)
end

return SystemeGestionArtefactsResurrection
