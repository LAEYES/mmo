SystemeGestionSanctuairesCelestes = {}

function SystemeGestionSanctuairesCelestes:EnterCelestialShrine(player, shrineName)
    print(player .. " enters the celestial shrine: " .. shrineName)
end

function SystemeGestionSanctuairesCelestes:ReceiveCelestialBlessing(player, blessing)
    print(player .. " receives a celestial blessing: " .. blessing)
end

return SystemeGestionSanctuairesCelestes
