SystemeGestionArtisanatAvance = {}

function SystemeGestionArtisanatAvance:CraftAdvancedItem(player, recipe, ingredients)
    print(player .. " crafts " .. recipe .. " using ingredients: " .. table.concat(ingredients, ", "))
end

function SystemeGestionArtisanatAvance:LearnRecipe(player, recipe)
    print(player .. " has learned a new crafting recipe: " .. recipe)
end

return SystemeGestionArtisanatAvance
