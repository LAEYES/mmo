SystemeCompetencesTalentsAvances = {}

function SystemeCompetencesTalentsAvances:UnlockAdvancedSkill(player, skill)
    print(player .. " unlocks advanced skill: " .. skill)
end

function SystemeCompetencesTalentsAvances:UpgradeTalent(player, talent)
    print(player .. " upgrades advanced talent: " .. talent)
end

return SystemeCompetencesTalentsAvances
