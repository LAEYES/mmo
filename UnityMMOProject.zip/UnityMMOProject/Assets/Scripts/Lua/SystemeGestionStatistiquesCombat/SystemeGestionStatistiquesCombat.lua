SystemeGestionStatistiquesCombat = {}

function SystemeGestionStatistiquesCombat:TrackDamage(player, damage)
    print(player .. " has dealt " .. damage .. " points of damage")
end

function SystemeGestionStatistiquesCombat:TrackHealing(player, healing)
    print(player .. " has healed " .. healing .. " points")
end

return SystemeGestionStatistiquesCombat
