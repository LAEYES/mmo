SystemeGestionCreaturesMythiques = {}

function SystemeGestionCreaturesMythiques:TameMythicalCreature(player, creatureName)
    print(player .. " tames the mythical creature: " .. creatureName)
end

function SystemeGestionCreaturesMythiques:SummonMythicalCreature(player, creatureName)
    print(player .. " summons the mythical creature: " .. creatureName)
end

return SystemeGestionCreaturesMythiques
