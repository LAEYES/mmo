SystemeGestionParcheminsSavoir = {}

function SystemeGestionParcheminsSavoir:DiscoverKnowledgeScroll(player, scrollName)
    print(player .. " discovers a knowledge scroll: " .. scrollName)
end

function SystemeGestionParcheminsSavoir:ReadScroll(player, scrollName)
    print(player .. " reads the knowledge scroll: " .. scrollName)
end

return SystemeGestionParcheminsSavoir
