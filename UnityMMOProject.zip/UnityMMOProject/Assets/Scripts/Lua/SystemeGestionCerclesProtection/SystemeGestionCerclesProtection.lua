SystemeGestionCerclesProtection = {}

function SystemeGestionCerclesProtection:CreateProtectionCircle(player, circleType)
    print(player .. " creates a protection circle of type: " .. circleType)
end

function SystemeGestionCerclesProtection:ActivateCircleEffect(player, effectType)
    print(player .. " activates the protection circle's effect: " .. effectType)
end

return SystemeGestionCerclesProtection
