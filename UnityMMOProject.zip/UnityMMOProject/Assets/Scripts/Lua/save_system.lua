-- Save system for saving and loading game state
SaveSystem = {}

function SaveSystem:SaveGame(player, world)
    print('Saving game...')
    -- Placeholder code for saving player and world data
end

function SaveSystem:LoadGame()
    print('Loading game...')
    -- Placeholder code for loading player and world data
end
