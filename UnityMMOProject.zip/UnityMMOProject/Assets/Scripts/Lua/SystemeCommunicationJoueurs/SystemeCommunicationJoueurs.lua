SystemeCommunicationJoueurs = {}

function SystemeCommunicationJoueurs:SendMessage(player, message)
    print(player .. " says: " .. message)
end

function SystemeCommunicationJoueurs:PrivateMessage(sender, receiver, message)
    print(sender .. " whispers to " .. receiver .. ": " .. message)
end

function SystemeCommunicationJoueurs:JoinChannel(player, channelName)
    print(player .. " joins the channel: " .. channelName)
end

return SystemeCommunicationJoueurs
