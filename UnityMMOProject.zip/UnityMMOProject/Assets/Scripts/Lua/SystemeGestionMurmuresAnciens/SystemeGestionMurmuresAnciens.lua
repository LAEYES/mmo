SystemeGestionMurmuresAnciens = {}

function SystemeGestionMurmuresAnciens:HearAncientWhisper(player, whisper)
    print(player .. " hears an ancient whisper: " .. whisper)
end

function SystemeGestionMurmuresAnciens:UnlockAncientSecret(player, secret)
    print(player .. " unlocks an ancient secret: " .. secret)
end

return SystemeGestionMurmuresAnciens
