SystemeGestionFontainesVie = {}

function SystemeGestionFontainesVie:FindLifeFountain(player, fountainName)
    print(player .. " finds the life fountain: " .. fountainName)
end

function SystemeGestionFontainesVie:DrinkFromFountain(player, fountainName)
    print(player .. " drinks from the life fountain: " .. fountainName)
end

return SystemeGestionFontainesVie
