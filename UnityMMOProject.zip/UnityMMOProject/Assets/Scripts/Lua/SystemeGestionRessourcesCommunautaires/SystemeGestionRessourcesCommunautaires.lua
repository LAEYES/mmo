SystemeGestionRessourcesCommunautaires = {}

function SystemeGestionRessourcesCommunautaires:AddToCommunityStock(player, resource, amount)
    print(player .. " adds " .. amount .. " units of " .. resource .. " to the community stock")
end

function SystemeGestionRessourcesCommunautaires:UseCommunityResource(player, resource, amount)
    print(player .. " uses " .. amount .. " units of " .. resource .. " from the community stock")
end

return SystemeGestionRessourcesCommunautaires
