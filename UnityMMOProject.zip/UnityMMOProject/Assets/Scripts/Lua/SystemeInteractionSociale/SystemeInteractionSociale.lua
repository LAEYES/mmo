SystemeInteractionSociale = {}

function SystemeInteractionSociale:SendEmote(player, emote)
    print(player .. " sends emote: " .. emote)
end

function SystemeInteractionSociale:TradeItem(player1, player2, item)
    print(player1 .. " trades " .. item .. " with " .. player2)
end

return SystemeInteractionSociale
