SystemeGestionSanctuairesAnciens = {}

function SystemeGestionSanctuairesAnciens:EnterAncientShrine(player, shrineName)
    print(player .. " enters the ancient shrine: " .. shrineName)
end

function SystemeGestionSanctuairesAnciens:GainAncientWisdom(player, wisdomType)
    print(player .. " gains ancient wisdom of type: " .. wisdomType)
end

return SystemeGestionSanctuairesAnciens
