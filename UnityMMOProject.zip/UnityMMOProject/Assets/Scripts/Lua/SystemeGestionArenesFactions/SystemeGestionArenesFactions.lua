SystemeGestionArenesFactions = {}

function SystemeGestionArenesFactions:EnterFactionArena(player, faction, arenaName)
    print(player .. " from faction " .. faction .. " enters the arena: " .. arenaName)
end

function SystemeGestionArenesFactions:WinArenaBattle(player, arenaName)
    print(player .. " wins the battle in arena: " .. arenaName)
end

return SystemeGestionArenesFactions
