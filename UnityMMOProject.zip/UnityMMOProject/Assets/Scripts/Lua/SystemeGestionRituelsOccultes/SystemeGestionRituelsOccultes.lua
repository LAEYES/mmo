SystemeGestionRituelsOccultes = {}

function SystemeGestionRituelsOccultes:PerformRitual(player, ritualName)
    print(player .. " performs the occult ritual: " .. ritualName)
end

function SystemeGestionRituelsOccultes:SummonCreature(player, creatureName)
    print(player .. " summons the creature: " .. creatureName)
end

return SystemeGestionRituelsOccultes
