SystemeGestionBetesMythiques = {}

function SystemeGestionBetesMythiques:EncounterMythicalBeast(player, beastName)
    print(player .. " encounters the mythical beast: " .. beastName)
end

function SystemeGestionBetesMythiques:TameBeast(player, beastName)
    print(player .. " tames the mythical beast: " .. beastName)
end

return SystemeGestionBetesMythiques
