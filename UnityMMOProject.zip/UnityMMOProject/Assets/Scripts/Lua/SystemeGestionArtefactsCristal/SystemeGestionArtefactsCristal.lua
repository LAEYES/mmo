SystemeGestionArtefactsCristal = {}

function SystemeGestionArtefactsCristal:DiscoverCrystalArtifact(player, artifactName)
    print(player .. " discovers a crystal artifact: " .. artifactName)
end

function SystemeGestionArtefactsCristal:ActivateCrystalArtifact(player, artifactName)
    print(player .. " activates the crystal artifact: " .. artifactName)
end

return SystemeGestionArtefactsCristal
