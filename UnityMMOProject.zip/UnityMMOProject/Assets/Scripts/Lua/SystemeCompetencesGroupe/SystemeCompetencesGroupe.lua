SystemeCompetencesGroupe = {}

function SystemeCompetencesGroupe:ActivateGroupSkill(skillName, players)
    print("Activating group skill: " .. skillName)
    for _, player in ipairs(players) do
        print(player .. " contributes to the group skill.")
    end
end

function SystemeCompetencesGroupe:EndGroupSkill(skillName)
    print("Group skill " .. skillName .. " has ended.")
end

return SystemeCompetencesGroupe
