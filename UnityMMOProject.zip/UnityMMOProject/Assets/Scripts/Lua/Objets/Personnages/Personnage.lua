Personnage = {}

function Personnage:Create(name, class, level)
    self.name = name
    self.class = class
    self.level = level
    print("Created character: " .. name .. ", Class: " .. class .. ", Level: " .. level)
end

function Personnage:LevelUp()
    self.level = self.level + 1
    print(self.name .. " levels up to " .. self.level)
end

return Personnage
