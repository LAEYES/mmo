Equipement = {}

function Equipement:Create(name, type, rarity)
    self.name = name
    self.type = type
    self.rarity = rarity
    print("Created equipment: " .. name .. ", Type: " .. type .. ", Rarity: " .. rarity)
end

function Equipement:Equip(player)
    print(player .. " equips " .. self.name)
end

return Equipement
