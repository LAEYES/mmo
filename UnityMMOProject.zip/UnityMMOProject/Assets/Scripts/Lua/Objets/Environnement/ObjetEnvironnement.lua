ObjetEnvironnement = {}

function ObjetEnvironnement:Create(name, interactionType)
    self.name = name
    self.interactionType = interactionType
    print("Created environment object: " .. name .. ", Interaction: " .. interactionType)
end

function ObjetEnvironnement:Interact(player)
    print(player .. " interacts with " .. self.name)
end

return ObjetEnvironnement
