Monstre = {}

function Monstre:Create(name, level, health)
    self.name = name
    self.level = level
    self.health = health
    print("Created monster: " .. name .. ", Level: " .. level .. ", Health: " .. health)
end

function Monstre:Attack(player, damage)
    print(self.name .. " attacks " .. player .. " and deals " .. damage .. " damage")
end

return Monstre
