Consommable = {}

function Consommable:Create(name, effect)
    self.name = name
    self.effect = effect
    print("Created consumable: " .. name .. ", Effect: " .. effect)
end

function Consommable:Use(player)
    print(player .. " uses " .. self.name .. " and gains: " .. self.effect)
end

return Consommable
