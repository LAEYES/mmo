SystemeGestionAutelsElements = {}

function SystemeGestionAutelsElements:ActivateAltar(player, elementType)
    print(player .. " activates the elemental altar of type: " .. elementType)
end

function SystemeGestionAutelsElements:ReceiveElementalBlessing(player, elementType)
    print(player .. " receives an elemental blessing from the altar: " .. elementType)
end

return SystemeGestionAutelsElements
