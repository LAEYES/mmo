SystemeClassement = {}

function SystemeClassement:AddPlayerScore(player, score)
    print(player .. " has achieved a score of " .. score)
end

function SystemeClassement:DisplayLeaderboard()
    print("Displaying the leaderboard")
    local leaderboard = {
        {player = "Player1", score = 2000},
        {player = "Player2", score = 1500}
    }
    for i, entry in ipairs(leaderboard) do
        print(i .. ". " .. entry.player .. " - Score: " .. entry.score)
    end
end

return SystemeClassement
