SystemeGestionCompetencesSociales = {}

function SystemeGestionCompetencesSociales:IncreaseCharisma(player, amount)
    print(player .. " increases charisma by " .. amount)
end

function SystemeGestionCompetencesSociales:UseDiplomacy(player, target)
    print(player .. " uses diplomacy on " .. target)
end

return SystemeGestionCompetencesSociales
