-- Dialogue system
Dialogue = {}

function Dialogue:StartDialogue(npcName, dialogueLines)
    print(npcName .. ' says:')
    for _, line in ipairs(dialogueLines) do
        print(line)
    end
end
