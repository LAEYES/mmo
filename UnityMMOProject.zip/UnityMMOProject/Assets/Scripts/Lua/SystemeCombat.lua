SystemeCombat = {}

function SystemeCombat:StartCombat(player, target)
    print(player .. " engages in combat with " .. target)
end

function SystemeCombat:ApplyDamage(player, target, damage)
    print(player .. " deals " .. damage .. " damage to " .. target)
end

function SystemeCombat:UseSkill(player, skill, target)
    print(player .. " uses skill: " .. skill .. " on " .. target)
end

return SystemeCombat
