SystemeGestionEpreuvesSurvie = {}

function SystemeGestionEpreuvesSurvie:StartSurvivalTrial(player, trialName)
    print(player .. " starts the survival trial: " .. trialName)
end

function SystemeGestionEpreuvesSurvie:CompleteSurvivalTrial(player, trialName)
    print(player .. " completes the survival trial: " .. trialName)
end

return SystemeGestionEpreuvesSurvie
