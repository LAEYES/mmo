SystemeRessourcesLimitees = {}

function SystemeRessourcesLimitees:SpawnResource(resourceType, location)
    print(resourceType .. " has spawned at " .. location)
end

function SystemeRessourcesLimitees:DepleteResource(resourceType, location)
    print(resourceType .. " at " .. location .. " has been depleted")
end

function SystemeRessourcesLimitees:RegenerateResource(resourceType, location, rate)
    print("Regenerating " .. resourceType .. " at " .. location .. " with rate " .. rate)
end

return SystemeRessourcesLimitees
