SystemeGestionLogins = {}

function SystemeGestionLogins:Login(player, password)
    print("Logging in player: " .. player)
end

function SystemeGestionLogins:Logout(player)
    print(player .. " has logged out.")
end

function SystemeGestionLogins:EnableTwoFactorAuthentication(player)
    print("Two-factor authentication enabled for: " .. player)
end

return SystemeGestionLogins
