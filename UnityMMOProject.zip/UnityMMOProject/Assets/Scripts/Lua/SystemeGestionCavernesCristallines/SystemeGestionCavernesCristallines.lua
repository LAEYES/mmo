SystemeGestionCavernesCristallines = {}

function SystemeGestionCavernesCristallines:EnterCrystalCave(player, caveName)
    print(player .. " enters the crystal cave: " .. caveName)
end

function SystemeGestionCavernesCristallines:CollectCrystal(player, crystalType)
    print(player .. " collects a " .. crystalType .. " crystal")
end

return SystemeGestionCavernesCristallines
