CompagnonAI = {}

function CompagnonAI:FollowPlayer(player)
    print("Companion follows " .. player)
end

function CompagnonAI:AssistInCombat(player, enemy)
    print("Companion assists " .. player .. " in combat against " .. enemy)
end

function CompagnonAI:Stay()
    print("Companion stays in place.")
end

return CompagnonAI
