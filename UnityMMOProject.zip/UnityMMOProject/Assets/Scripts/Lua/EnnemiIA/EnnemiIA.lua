EnnemiIA = {}

function EnnemiIA:Attack(target)
    print("Enemy attacks " .. target)
end

function EnnemiIA:Defend()
    print("Enemy defends")
end

return EnnemiIA
