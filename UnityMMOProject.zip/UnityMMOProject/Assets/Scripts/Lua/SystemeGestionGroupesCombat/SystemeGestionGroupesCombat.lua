SystemeGestionGroupesCombat = {}

function SystemeGestionGroupesCombat:CreateGroup(groupName, players)
    print("Group " .. groupName .. " created with members: " .. table.concat(players, ", "))
end

function SystemeGestionGroupesCombat:AddPlayerToGroup(groupName, player)
    print(player .. " has joined the group: " .. groupName)
end

function SystemeGestionGroupesCombat:GroupAttack(groupName, target)
    print("Group " .. groupName .. " attacks " .. target)
end

return SystemeGestionGroupesCombat
