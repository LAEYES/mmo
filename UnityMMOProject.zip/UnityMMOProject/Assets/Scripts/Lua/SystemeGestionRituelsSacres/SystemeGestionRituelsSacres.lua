SystemeGestionRituelsSacres = {}

function SystemeGestionRituelsSacres:PerformSacredRitual(player, ritualName)
    print(player .. " performs the sacred ritual: " .. ritualName)
end

function SystemeGestionRituelsSacres:ReceiveRitualBlessing(player, blessingType)
    print(player .. " receives a ritual blessing of type: " .. blessingType)
end

return SystemeGestionRituelsSacres
