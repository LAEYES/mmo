SystemeGestionSanctuairesLumiere = {}

function SystemeGestionSanctuairesLumiere:EnterLightSanctuary(player, sanctuaryName)
    print(player .. " enters the light sanctuary: " .. sanctuaryName)
end

function SystemeGestionSanctuairesLumiere:ReceiveLightBlessing(player, blessingType)
    print(player .. " receives a light blessing of type: " .. blessingType)
end

return SystemeGestionSanctuairesLumiere
