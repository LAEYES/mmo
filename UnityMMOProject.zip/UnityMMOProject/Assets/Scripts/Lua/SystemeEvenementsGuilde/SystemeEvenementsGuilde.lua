SystemeEvenementsGuilde = {}

function SystemeEvenementsGuilde:CreateGuildEvent(guildName, eventName)
    print("Guild " .. guildName .. " has initiated event: " .. eventName)
end

function SystemeEvenementsGuilde:JoinGuildEvent(player, eventName)
    print(player .. " joins the guild event: " .. eventName)
end

function SystemeEvenementsGuilde:CompleteGuildEvent(guildName, eventName)
    print("Guild event " .. eventName .. " completed by guild " .. guildName)
end

return SystemeEvenementsGuilde
