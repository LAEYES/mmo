SystemeGestionTotemsSacres = {}

function SystemeGestionTotemsSacres:BuildSacredTotem(player, totemType)
    print(player .. " builds a sacred totem of type: " .. totemType)
end

function SystemeGestionTotemsSacres:ActivateTotemPower(player, totemType)
    print(player .. " activates the power of the sacred totem: " .. totemType)
end

return SystemeGestionTotemsSacres
