SystemeGestionTerritoiresEnsorcelles = {}

function SystemeGestionTerritoiresEnsorcelles:ClaimEnchantedTerritory(player, territoryName)
    print(player .. " claims the enchanted territory: " .. territoryName)
end

function SystemeGestionTerritoiresEnsorcelles:LiftTerritoryCurse(player, territoryName)
    print(player .. " lifts the curse from the enchanted territory: " .. territoryName)
end

return SystemeGestionTerritoiresEnsorcelles
