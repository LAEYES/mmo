SystemeGestionEnergiesLune = {}

function SystemeGestionEnergiesLune:CollectMoonEnergy(player, moonPhase)
    print(player .. " collects energy from the moon phase: " .. moonPhase)
end

function SystemeGestionEnergiesLune:UseMoonEnergy(player, moonPhase, power)
    print(player .. " uses the energy of the " .. moonPhase .. " to activate the power: " .. power)
end

return SystemeGestionEnergiesLune
