SystemeGestionGardiensAncestraux = {}

function SystemeGestionGardiensAncestraux:SummonGuardian(player, guardianName)
    print(player .. " summons the ancient guardian: " .. guardianName)
end

function SystemeGestionGardiensAncestraux:DismissGuardian(player, guardianName)
    print(player .. " dismisses the ancient guardian: " .. guardianName)
end

return SystemeGestionGardiensAncestraux
