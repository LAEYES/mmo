SystemeGestionTotemsSpirituels = {}

function SystemeGestionTotemsSpirituels:PlaceSpiritualTotem(player, totemName)
    print(player .. " places a spiritual totem: " .. totemName)
end

function SystemeGestionTotemsSpirituels:ActivateTotemProtection(player, totemType)
    print(player .. " activates the totem protection of type: " .. totemType)
end

return SystemeGestionTotemsSpirituels
