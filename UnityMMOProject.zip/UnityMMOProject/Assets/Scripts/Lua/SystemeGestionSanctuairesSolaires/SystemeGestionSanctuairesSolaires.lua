SystemeGestionSanctuairesSolaires = {}

function SystemeGestionSanctuairesSolaires:EnterSolarSanctuary(player, sanctuaryName)
    print(player .. " enters the solar sanctuary: " .. sanctuaryName)
end

function SystemeGestionSanctuairesSolaires:AbsorbSolarPower(player, powerType)
    print(player .. " absorbs solar power of type: " .. powerType)
end

return SystemeGestionSanctuairesSolaires
