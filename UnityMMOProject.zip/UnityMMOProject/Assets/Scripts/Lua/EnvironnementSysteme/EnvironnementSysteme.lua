EnvironnementSysteme = {}

function EnvironnementSysteme:SetWeather(weather)
    self.weather = weather
    print("Weather set to " .. weather)
end

function EnvironnementSysteme:SetTimeOfDay(time)
    self.timeOfDay = time
    print("Time of day set to " .. time)
end

return EnvironnementSysteme
