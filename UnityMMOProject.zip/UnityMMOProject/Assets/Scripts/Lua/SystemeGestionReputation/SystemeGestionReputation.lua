SystemeGestionReputation = {}

function SystemeGestionReputation:IncreaseReputation(player, faction, points)
    print(player .. " gains " .. points .. " reputation points with " .. faction)
end

function SystemeGestionReputation:DecreaseReputation(player, faction, points)
    print(player .. " loses " .. points .. " reputation points with " .. faction)
end

return SystemeGestionReputation
