SystemeGestionGardiensEternels = {}

function SystemeGestionGardiensEternels:SummonEternalGuardian(player, guardianName)
    print(player .. " summons the eternal guardian: " .. guardianName)
end

function SystemeGestionGardiensEternels:DismissEternalGuardian(player, guardianName)
    print(player .. " dismisses the eternal guardian: " .. guardianName)
end

return SystemeGestionGardiensEternels
