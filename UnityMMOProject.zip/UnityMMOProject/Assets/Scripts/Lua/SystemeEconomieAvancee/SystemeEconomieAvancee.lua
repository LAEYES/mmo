SystemeEconomieAvancee = {}

function SystemeEconomieAvancee:SetTaxRate(taxRate)
    print("Setting tax rate to " .. taxRate .. "%")
end

function SystemeEconomieAvancee:AdjustInflation(rate)
    print("Adjusting inflation rate by " .. rate .. "%")
end

function SystemeEconomieAvancee:HandleTransaction(player, amount)
    print(player .. " completes a transaction of " .. amount .. " coins")
end

return SystemeEconomieAvancee
