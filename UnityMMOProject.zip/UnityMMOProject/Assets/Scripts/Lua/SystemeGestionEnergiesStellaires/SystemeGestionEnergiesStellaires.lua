SystemeGestionEnergiesStellaires = {}

function SystemeGestionEnergiesStellaires:ChannelStellarEnergy(player, energyType)
    print(player .. " channels stellar energy of type: " .. energyType)
end

function SystemeGestionEnergiesStellaires:UseStellarPower(player, powerType)
    print(player .. " uses the power of the stars: " .. powerType)
end

return SystemeGestionEnergiesStellaires
