SystemeEvenementsDynamiques = {}

function SystemeEvenementsDynamiques:CreateEvent(eventName, location)
    print("Dynamic event '" .. eventName .. "' has been created at " .. location)
end

function SystemeEvenementsDynamiques:TriggerEvent(eventName, player)
    print(player .. " triggers the dynamic event: " .. eventName)
end

function SystemeEvenementsDynamiques:EndEvent(eventName)
    print("The dynamic event '" .. eventName .. "' has ended.")
end

return SystemeEvenementsDynamiques
