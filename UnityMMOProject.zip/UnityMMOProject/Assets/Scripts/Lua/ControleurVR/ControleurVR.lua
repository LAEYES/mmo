ControleurVR = {}

function ControleurVR:ActivateSkillVR(player, skill)
    print(player .. " activates VR skill: " .. skill)
end

function ControleurVR:DeactivateSkillVR(player, skill)
    print(player .. " deactivates VR skill: " .. skill)
end

return ControleurVR
