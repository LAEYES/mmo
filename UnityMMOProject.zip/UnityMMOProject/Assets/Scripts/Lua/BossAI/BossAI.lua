BossAI = {}

function BossAI:Engage(player)
    print("Boss engages in combat with " .. player)
end

function BossAI:UseSpecialAttack()
    print("Boss uses a powerful special attack!")
end

function BossAI:Retreat()
    print("Boss retreats to recover.")
end

return BossAI
