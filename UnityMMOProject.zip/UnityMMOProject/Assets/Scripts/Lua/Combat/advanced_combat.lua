-- Advanced combat system
function AdvancedCombat(player, enemy)
    print('Advanced combat between Player and ' .. enemy.name)
    while player.health > 0 and enemy.health > 0 do
        player:Attack(enemy)
        if enemy.health <= 0 then
            print(enemy.name .. ' has been defeated!')
            break
        end
        enemy:Attack(player)
        if player.health <= 0 then
            print('Player has been defeated!')
        end
    end
end
