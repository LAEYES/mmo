SystemeGestionOrbesElementaires = {}

function SystemeGestionOrbesElementaires:FindElementalOrb(player, elementType)
    print(player .. " finds an elemental orb of type: " .. elementType)
end

function SystemeGestionOrbesElementaires:UseOrbElementalPower(player, elementType)
    print(player .. " uses the elemental power of type: " .. elementType)
end

return SystemeGestionOrbesElementaires
