SystemeGestionAmisListeNoire = {}

function SystemeGestionAmisListeNoire:AddFriend(player, friend)
    print(player .. " has added " .. friend .. " as a friend.")
end

function SystemeGestionAmisListeNoire:BlockPlayer(player, target)
    print(player .. " has blocked " .. target)
end

function SystemeGestionAmisListeNoire:RemoveFriend(player, friend)
    print(player .. " has removed " .. friend .. " from the friend list.")
end

return SystemeGestionAmisListeNoire
