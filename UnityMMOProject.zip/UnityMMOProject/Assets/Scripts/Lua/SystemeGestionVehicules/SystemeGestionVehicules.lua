SystemeGestionVehicules = {}

function SystemeGestionVehicules:SummonVehicle(player, vehicle)
    print(player .. " summons a vehicle: " .. vehicle)
end

function SystemeGestionVehicules:DriveToLocation(player, location)
    print(player .. " drives to " .. location)
end

function SystemeGestionVehicules:ParkVehicle(player, location)
    print(player .. " parks the vehicle at " .. location)
end

return SystemeGestionVehicules
