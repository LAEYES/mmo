SystemeGestionRaid = {}

function SystemeGestionRaid:CreateRaidGroup(raidName, players)
    print("Raid group " .. raidName .. " created with players: " .. table.concat(players, ", "))
end

function SystemeGestionRaid:InviteToRaid(player, raidName)
    print(player .. " is invited to join raid: " .. raidName)
end

function SystemeGestionRaid:StartRaid(raidName)
    print("Raid " .. raidName .. " has started.")
end

return SystemeGestionRaid
