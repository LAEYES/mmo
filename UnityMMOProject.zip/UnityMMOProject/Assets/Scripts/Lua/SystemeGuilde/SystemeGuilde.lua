SystemeGuilde = {}

function SystemeGuilde:CreateGuild(player, guildName)
    print(player .. " creates the guild: " .. guildName)
end

function SystemeGuilde:AddMember(guildName, player)
    print(player .. " joins the guild: " .. guildName)
end

function SystemeGuilde:SetGuildRank(player, rank)
    print(player .. " is assigned the rank: " .. rank .. " in the guild.")
end

return SystemeGuilde
