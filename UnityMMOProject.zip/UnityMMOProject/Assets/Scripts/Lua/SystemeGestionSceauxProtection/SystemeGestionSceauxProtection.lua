SystemeGestionSceauxProtection = {}

function SystemeGestionSceauxProtection:CreateProtectionSeal(player, sealType)
    print(player .. " creates a protection seal of type: " .. sealType)
end

function SystemeGestionSceauxProtection:ActivateSeal(player)
    print(player .. " activates the protection seal for enhanced defense.")
end

return SystemeGestionSceauxProtection
