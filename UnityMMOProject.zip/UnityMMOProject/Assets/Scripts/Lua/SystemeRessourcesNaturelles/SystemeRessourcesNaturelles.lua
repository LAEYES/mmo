SystemeRessourcesNaturelles = {}

function SystemeRessourcesNaturelles:HarvestResource(player, resourceType)
    print(player .. " harvests " .. resourceType)
end

function SystemeRessourcesNaturelles:RegenerateResource(resourceType, amount)
    print("Regenerating " .. amount .. " units of " .. resourceType)
end

return SystemeRessourcesNaturelles
