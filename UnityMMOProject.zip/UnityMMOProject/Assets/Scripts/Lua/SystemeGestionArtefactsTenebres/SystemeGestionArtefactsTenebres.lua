SystemeGestionArtefactsTenebres = {}

function SystemeGestionArtefactsTenebres:DiscoverDarkArtifact(player, artifactName)
    print(player .. " discovers a dark artifact: " .. artifactName)
end

function SystemeGestionArtefactsTenebres:ActivateDarkArtifact(player, artifactName)
    print(player .. " activates the dark artifact: " .. artifactName)
end

return SystemeGestionArtefactsTenebres
