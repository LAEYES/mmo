SystemeGestionSaisons = {}

function SystemeGestionSaisons:SetSeason(season)
    print("The current season has changed to " .. season)
end

function SystemeGestionSaisons:ApplySeasonalEffects(season)
    print("Applying effects for the season: " .. season)
end

return SystemeGestionSaisons
