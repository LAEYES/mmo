SystemeGestionReliquesEternite = {}

function SystemeGestionReliquesEternite:FindEternalRelic(player, relicName)
    print(player .. " finds an eternal relic: " .. relicName)
end

function SystemeGestionReliquesEternite:UseRelicPower(player, powerType)
    print(player .. " uses the power of the eternal relic: " .. powerType)
end

return SystemeGestionReliquesEternite
