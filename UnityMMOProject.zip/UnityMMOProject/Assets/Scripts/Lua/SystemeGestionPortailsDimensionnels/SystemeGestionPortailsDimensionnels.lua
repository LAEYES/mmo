SystemeGestionPortailsDimensionnels = {}

function SystemeGestionPortailsDimensionnels:OpenDimensionalPortal(player, portalName)
    print(player .. " opens a dimensional portal to: " .. portalName)
end

function SystemeGestionPortailsDimensionnels:TravelToDimension(player, destination)
    print(player .. " travels to another dimension: " .. destination)
end

return SystemeGestionPortailsDimensionnels
