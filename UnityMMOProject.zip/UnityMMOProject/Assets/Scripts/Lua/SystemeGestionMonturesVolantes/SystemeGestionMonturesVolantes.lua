SystemeGestionMonturesVolantes = {}

function SystemeGestionMonturesVolantes:SummonFlyingMount(player, mountType)
    print(player .. " summons a flying mount: " .. mountType)
end

function SystemeGestionMonturesVolantes:FlyToLocation(player, location)
    print(player .. " flies to " .. location .. " with their flying mount")
end

return SystemeGestionMonturesVolantes
