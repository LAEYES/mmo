SystemeGestionSanctuairesOmbre = {}

function SystemeGestionSanctuairesOmbre:FindShadowSanctuary(player, sanctuaryName)
    print(player .. " finds a shadow sanctuary: " .. sanctuaryName)
end

function SystemeGestionSanctuairesOmbre:GainShadowPower(player, powerType)
    print(player .. " gains a shadow power of type: " .. powerType)
end

return SystemeGestionSanctuairesOmbre
