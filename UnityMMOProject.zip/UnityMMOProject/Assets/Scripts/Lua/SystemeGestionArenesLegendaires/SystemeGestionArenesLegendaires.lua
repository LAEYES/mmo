SystemeGestionArenesLegendaires = {}

function SystemeGestionArenesLegendaires:EnterArena(player, arenaName)
    print(player .. " enters the legendary arena: " .. arenaName)
end

function SystemeGestionArenesLegendaires:WinArenaBattle(player, arenaName)
    print(player .. " wins the battle in the legendary arena: " .. arenaName)
end

return SystemeGestionArenesLegendaires
