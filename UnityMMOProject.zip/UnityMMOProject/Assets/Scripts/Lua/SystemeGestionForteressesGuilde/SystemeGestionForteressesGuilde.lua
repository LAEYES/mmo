SystemeGestionForteressesGuilde = {}

function SystemeGestionForteressesGuilde:BuildGuildFortress(guildName, location)
    print("The guild " .. guildName .. " builds a fortress at " .. location)
end

function SystemeGestionForteressesGuilde:UpgradeGuildFortress(guildName, upgradeLevel)
    print("The guild " .. guildName .. " upgrades its fortress to level " .. upgradeLevel)
end

return SystemeGestionForteressesGuilde
