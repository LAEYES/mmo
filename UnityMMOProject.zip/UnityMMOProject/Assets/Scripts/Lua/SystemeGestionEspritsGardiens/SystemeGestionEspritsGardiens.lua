SystemeGestionEspritsGardiens = {}

function SystemeGestionEspritsGardiens:SummonGuardianSpirit(player, spiritName)
    print(player .. " summons the guardian spirit: " .. spiritName)
end

function SystemeGestionEspritsGardiens:ReceiveSpiritProtection(player, spiritName)
    print(player .. " receives protection from the guardian spirit: " .. spiritName)
end

return SystemeGestionEspritsGardiens
