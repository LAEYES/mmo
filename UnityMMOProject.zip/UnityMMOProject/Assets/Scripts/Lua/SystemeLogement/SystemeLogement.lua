SystemeLogement = {}

function SystemeLogement:PurchaseHouse(player, houseType)
    print(player .. " purchases a " .. houseType .. " house.")
end

function SystemeLogement:DecorateHouse(player, item)
    print(player .. " decorates their house with " .. item)
end

return SystemeLogement
