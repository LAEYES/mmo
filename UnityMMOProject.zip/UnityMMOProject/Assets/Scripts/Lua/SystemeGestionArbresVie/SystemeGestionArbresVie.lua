SystemeGestionArbresVie = {}

function SystemeGestionArbresVie:ConnectToTreeOfLife(player, treeName)
    print(player .. " connects to the Tree of Life: " .. treeName)
end

function SystemeGestionArbresVie:GainRegeneration(player, regenerationType)
    print(player .. " gains regeneration from the Tree of Life of type: " .. regenerationType)
end

return SystemeGestionArbresVie
