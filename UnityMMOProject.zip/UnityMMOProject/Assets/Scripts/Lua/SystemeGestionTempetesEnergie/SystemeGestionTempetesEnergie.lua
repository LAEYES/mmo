SystemeGestionTempetesEnergie = {}

function SystemeGestionTempetesEnergie:SummonEnergyStorm(player, stormType)
    print(player .. " summons an energy storm of type: " .. stormType)
end

function SystemeGestionTempetesEnergie:ControlStorm(player, stormType)
    print(player .. " controls the energy storm: " .. stormType)
end

return SystemeGestionTempetesEnergie
