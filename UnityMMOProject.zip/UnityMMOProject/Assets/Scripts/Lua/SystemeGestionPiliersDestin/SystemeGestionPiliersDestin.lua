SystemeGestionPiliersDestin = {}

function SystemeGestionPiliersDestin:ActivateDestinyPillar(player, pillarName)
    print(player .. " activates the destiny pillar: " .. pillarName)
end

function SystemeGestionPiliersDestin:ReceivePillarBlessing(player, blessingType)
    print(player .. " receives a blessing from the destiny pillar: " .. blessingType)
end

return SystemeGestionPiliersDestin
