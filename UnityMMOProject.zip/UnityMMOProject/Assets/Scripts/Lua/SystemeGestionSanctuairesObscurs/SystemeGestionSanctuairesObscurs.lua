SystemeGestionSanctuairesObscurs = {}

function SystemeGestionSanctuairesObscurs:EnterDarkSanctuary(player, sanctuaryName)
    print(player .. " enters the dark sanctuary: " .. sanctuaryName)
end

function SystemeGestionSanctuairesObscurs:OvercomeDarkEnergy(player)
    print(player .. " overcomes the dark energy within the sanctuary")
end

return SystemeGestionSanctuairesObscurs
