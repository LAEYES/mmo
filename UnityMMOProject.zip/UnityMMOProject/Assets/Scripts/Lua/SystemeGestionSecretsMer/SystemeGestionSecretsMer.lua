SystemeGestionSecretsMer = {}

function SystemeGestionSecretsMer:DiscoverSeaSecret(player, secretName)
    print(player .. " discovers a sea secret: " .. secretName)
end

function SystemeGestionSecretsMer:InteractWithSeaCreature(player, creatureName)
    print(player .. " interacts with the sea creature: " .. creatureName)
end

return SystemeGestionSecretsMer
