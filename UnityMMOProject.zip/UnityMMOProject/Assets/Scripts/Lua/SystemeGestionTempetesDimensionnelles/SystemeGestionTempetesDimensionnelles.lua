SystemeGestionTempetesDimensionnelles = {}

function SystemeGestionTempetesDimensionnelles:EnterDimensionalStorm(player, stormName)
    print(player .. " enters the dimensional storm: " .. stormName)
end

function SystemeGestionTempetesDimensionnelles:ExitDimensionalStorm(player, stormName)
    print(player .. " exits the dimensional storm: " .. stormName)
end

return SystemeGestionTempetesDimensionnelles
