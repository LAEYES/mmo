SystemeGestionArtefactsRares = {}

function SystemeGestionArtefactsRares:DiscoverArtifact(player, artifact)
    print(player .. " has discovered a rare artifact: " .. artifact)
end

function SystemeGestionArtefactsRares:UseArtifact(player, artifact)
    print(player .. " uses the artifact: " .. artifact)
end

return SystemeGestionArtefactsRares
