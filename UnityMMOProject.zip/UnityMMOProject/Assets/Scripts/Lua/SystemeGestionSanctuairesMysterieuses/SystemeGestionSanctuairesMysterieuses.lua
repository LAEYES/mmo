SystemeGestionSanctuairesMysterieuses = {}

function SystemeGestionSanctuairesMysterieuses:DiscoverShrine(player, shrineName)
    print(player .. " discovers the mysterious shrine: " .. shrineName)
end

function SystemeGestionSanctuairesMysterieuses:ReceiveBlessing(player, shrineName, blessing)
    print(player .. " receives a blessing from the shrine: " .. shrineName .. " - " .. blessing)
end

return SystemeGestionSanctuairesMysterieuses
