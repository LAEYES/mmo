SystemeGestionSourcesMana = {}

function SystemeGestionSourcesMana:FindManaSource(player, sourceName)
    print(player .. " finds a mana source: " .. sourceName)
end

function SystemeGestionSourcesMana:RechargeMana(player, sourceName)
    print(player .. " recharges mana at the source: " .. sourceName)
end

return SystemeGestionSourcesMana
