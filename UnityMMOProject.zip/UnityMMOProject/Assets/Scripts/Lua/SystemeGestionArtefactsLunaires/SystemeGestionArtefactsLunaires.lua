SystemeGestionArtefactsLunaires = {}

function SystemeGestionArtefactsLunaires:FindLunarArtifact(player, artifactName)
    print(player .. " discovers a lunar artifact: " .. artifactName)
end

function SystemeGestionArtefactsLunaires:UseLunarPower(player, powerType)
    print(player .. " uses the lunar power of type: " .. powerType)
end

return SystemeGestionArtefactsLunaires
