SystemeGestionLabyrinthesEnchantes = {}

function SystemeGestionLabyrinthesEnchantes:EnterLabyrinth(player, labyrinthName)
    print(player .. " enters the enchanted labyrinth: " .. labyrinthName)
end

function SystemeGestionLabyrinthesEnchantes:NavigateLabyrinth(player, direction)
    print(player .. " navigates the labyrinth in the direction: " .. direction)
end

return SystemeGestionLabyrinthesEnchantes
