SystemeCompetencesPvP = {}

function SystemeCompetencesPvP:UsePvPSkill(player, skill, target)
    print(player .. " uses PvP skill " .. skill .. " on " .. target)
end

function SystemeCompetencesPvP:UpgradePvPSkill(player, skill)
    print(player .. " upgrades PvP skill: " .. skill)
end

return SystemeCompetencesPvP
