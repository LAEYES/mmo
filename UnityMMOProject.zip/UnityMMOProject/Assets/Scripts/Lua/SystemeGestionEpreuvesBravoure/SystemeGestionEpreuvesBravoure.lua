SystemeGestionEpreuvesBravoure = {}

function SystemeGestionEpreuvesBravoure:StartBraveryTrial(player, trialName)
    print(player .. " starts the bravery trial: " .. trialName)
end

function SystemeGestionEpreuvesBravoure:CompleteBraveryTrial(player, trialName)
    print(player .. " completes the bravery trial: " .. trialName)
end

return SystemeGestionEpreuvesBravoure
