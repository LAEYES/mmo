SystemePersonnalisationAvancee = {}

function SystemePersonnalisationAvancee:ChangeAppearance(player, feature, value)
    print(player .. " customizes " .. feature .. " to " .. value)
end

function SystemePersonnalisationAvancee:AddAccessory(player, accessory)
    print(player .. " equips accessory: " .. accessory)
end

return SystemePersonnalisationAvancee
