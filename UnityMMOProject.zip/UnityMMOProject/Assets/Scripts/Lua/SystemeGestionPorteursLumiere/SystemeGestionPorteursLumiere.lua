SystemeGestionPorteursLumiere = {}

function SystemeGestionPorteursLumiere:BecomeLightbearer(player)
    print(player .. " becomes a lightbearer, gaining healing and illumination powers")
end

function SystemeGestionPorteursLumiere:UseLightPower(player, powerType)
    print(player .. " uses the light power: " .. powerType)
end

return SystemeGestionPorteursLumiere
