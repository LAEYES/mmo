SystemeGestionPactesDemoniques = {}

function SystemeGestionPactesDemoniques:FormDemonicPact(player, demonName)
    print(player .. " forms a demonic pact with " .. demonName)
end

function SystemeGestionPactesDemoniques:UseDemonicPower(player, powerName)
    print(player .. " uses the demonic power: " .. powerName)
end

return SystemeGestionPactesDemoniques
