-- NPC system for managing non-player characters
NPC = {
    name = '',
    health = 100,
    position = {x = 0, y = 0, z = 0},
    dialogues = {}
}

function NPC:MoveTo(newPosition)
    self.position = newPosition
    print(self.name .. ' moves to position (' .. newPosition.x .. ', ' .. newPosition.y .. ', ' .. newPosition.z .. ')')
end

function NPC:Speak()
    for _, dialogue in ipairs(self.dialogues) do
        print(self.name .. ' says: ' .. dialogue)
    end
end

function NPC:TakeDamage(amount)
    self.health = self.health - amount
    if self.health <= 0 then
        self:Die()
    else
        print(self.name .. ' takes ' .. amount .. ' damage. Health now: ' .. self.health)
    end
end

function NPC:Die()
    print(self.name .. ' has died.')
end
