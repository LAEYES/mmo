SystemeGestionDimensionsParalleles = {}

function SystemeGestionDimensionsParalleles:EnterParallelDimension(player, dimensionName)
    print(player .. " enters the parallel dimension: " .. dimensionName)
end

function SystemeGestionDimensionsParalleles:ExitParallelDimension(player, dimensionName)
    print(player .. " exits the parallel dimension: " .. dimensionName)
end

return SystemeGestionDimensionsParalleles
