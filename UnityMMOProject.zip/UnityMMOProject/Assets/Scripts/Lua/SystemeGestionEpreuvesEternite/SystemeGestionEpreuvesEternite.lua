SystemeGestionEpreuvesEternite = {}

function SystemeGestionEpreuvesEternite:StartEternityTrial(player, trialName)
    print(player .. " starts the trial of eternity: " .. trialName)
end

function SystemeGestionEpreuvesEternite:CompleteTrial(player, trialName)
    print(player .. " completes the trial of eternity: " .. trialName .. " and earns eternal glory")
end

return SystemeGestionEpreuvesEternite
