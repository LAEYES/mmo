SystemeGestionObjetsLegende = {}

function SystemeGestionObjetsLegende:FindLegendaryItem(player, itemName)
    print(player .. " finds a legendary item: " .. itemName)
end

function SystemeGestionObjetsLegende:UpgradeLegendaryItem(player, itemName, upgradeLevel)
    print(player .. " upgrades the legendary item " .. itemName .. " to level " .. upgradeLevel)
end

return SystemeGestionObjetsLegende
