SystemeArtisanat = {}

function SystemeArtisanat:CraftItem(player, item, materials)
    local materialList = table.concat(materials, ", ")
    print(player .. " crafts " .. item .. " using materials: " .. materialList)
end

return SystemeArtisanat
