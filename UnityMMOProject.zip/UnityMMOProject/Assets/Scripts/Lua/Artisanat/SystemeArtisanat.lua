SystemeArtisanat = {}

function SystemeArtisanat:CraftItem(player, recipeID)
    print(player .. " crafts item with recipe: " .. recipeID)
end

function SystemeArtisanat:GatherResource(player, resourceType)
    print(player .. " gathers resource: " .. resourceType)
end

return SystemeArtisanat
