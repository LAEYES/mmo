TerrainProcedural = {}

function TerrainProcedural:GenerateTerrain(seed)
    math.randomseed(seed)
    print("Generating terrain with seed " .. seed)
end

return TerrainProcedural
