SystemeProgressionPersonnages = {}

function SystemeProgressionPersonnages:GainExperience(player, amount)
    print(player .. " gains " .. amount .. " experience points")
end

function SystemeProgressionPersonnages:LevelUp(player)
    print(player .. " levels up!")
end

return SystemeProgressionPersonnages
