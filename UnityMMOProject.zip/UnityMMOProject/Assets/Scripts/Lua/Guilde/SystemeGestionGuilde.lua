SystemeGestionGuilde = {}

function SystemeGestionGuilde:CreateGuild(player, guildName)
    print(player .. " creates a guild: " .. guildName)
end

function SystemeGestionGuilde:JoinGuild(player, guildName)
    print(player .. " joins the guild: " .. guildName)
end

return SystemeGestionGuilde
