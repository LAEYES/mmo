SystemeGestionCristauxLumiere = {}

function SystemeGestionCristauxLumiere:CollectLightCrystal(player, crystalType)
    print(player .. " collects a light crystal of type: " .. crystalType)
end

function SystemeGestionCristauxLumiere:UseCrystalPower(player, powerType)
    print(player .. " uses the power of the light crystal: " .. powerType)
end

return SystemeGestionCristauxLumiere
