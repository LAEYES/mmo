SystemeGestionPouvoirsCelestes = {}

function SystemeGestionPouvoirsCelestes:ReceiveCelestialPower(player, powerType)
    print(player .. " receives a celestial power of type: " .. powerType)
end

function SystemeGestionPouvoirsCelestes:ActivateCelestialShield(player)
    print(player .. " activates the celestial shield")
end

return SystemeGestionPouvoirsCelestes
