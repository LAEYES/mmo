SystemePersonnalisationPersonnages = {}

function SystemePersonnalisationPersonnages:ChangeAppearance(player, attribute, value)
    print(player .. " changes " .. attribute .. " to " .. value)
end

function SystemePersonnalisationPersonnages:EquipItem(player, item)
    print(player .. " equips " .. item)
end

return SystemePersonnalisationPersonnages
