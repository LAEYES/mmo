SystemeGestionRunesMystiques = {}

function SystemeGestionRunesMystiques:FindMysticRune(player, runeName)
    print(player .. " finds a mystic rune: " .. runeName)
end

function SystemeGestionRunesMystiques:ActivateRune(player, runeType)
    print(player .. " activates the rune of type: " .. runeType)
end

return SystemeGestionRunesMystiques
