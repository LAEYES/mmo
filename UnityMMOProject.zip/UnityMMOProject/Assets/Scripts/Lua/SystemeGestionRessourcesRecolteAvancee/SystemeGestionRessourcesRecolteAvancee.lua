SystemeGestionRessourcesRecolteAvancee = {}

function SystemeGestionRessourcesRecolteAvancee:HarvestResource(player, resourceType, quantity)
    print(player .. " harvests " .. quantity .. " units of " .. resourceType)
end

function SystemeGestionRessourcesRecolteAvancee:RefineResource(player, resourceType)
    print(player .. " refines the resource: " .. resourceType)
end

return SystemeGestionRessourcesRecolteAvancee
