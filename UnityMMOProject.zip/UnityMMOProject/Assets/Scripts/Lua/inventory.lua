-- Inventory system
Inventory = {
    items = {}
}

function Inventory:AddItem(item)
    table.insert(self.items, item)
    print(item.name .. ' has been added to your inventory.')
end

function Inventory:RemoveItem(itemName)
    for i, item in ipairs(self.items) do
        if item.name == itemName then
            table.remove(self.items, i)
            print(itemName .. ' has been removed from your inventory.')
            return
        end
    end
    print(itemName .. ' not found in inventory.')
end

function Inventory:ListItems()
    print('Inventory:')
    for _, item in ipairs(self.items) do
        print('- ' .. item.name)
    end
end
