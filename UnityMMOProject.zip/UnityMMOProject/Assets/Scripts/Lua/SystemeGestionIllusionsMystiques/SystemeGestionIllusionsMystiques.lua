SystemeGestionIllusionsMystiques = {}

function SystemeGestionIllusionsMystiques:CreateMysticIllusion(player, illusionType)
    print(player .. " creates a mystic illusion of type: " .. illusionType)
end

function SystemeGestionIllusionsMystiques:DispelIllusion(player, illusionType)
    print(player .. " dispels the mystic illusion of type: " .. illusionType)
end

return SystemeGestionIllusionsMystiques
