SystemeGestionReliquesSang = {}

function SystemeGestionReliquesSang:FindBloodRelic(player, relicName)
    print(player .. " finds a blood relic: " .. relicName)
end

function SystemeGestionReliquesSang:ActivateBloodRelic(player, relicName)
    print(player .. " activates the blood relic: " .. relicName)
end

return SystemeGestionReliquesSang
