SystemeGestionForetsEternelles = {}

function SystemeGestionForetsEternelles:EnterEternalForest(player, forestName)
    print(player .. " enters the eternal forest: " .. forestName)
end

function SystemeGestionForetsEternelles:GatherRareResource(player, resourceType)
    print(player .. " gathers a rare resource of type: " .. resourceType .. " from the eternal forest")
end

return SystemeGestionForetsEternelles
