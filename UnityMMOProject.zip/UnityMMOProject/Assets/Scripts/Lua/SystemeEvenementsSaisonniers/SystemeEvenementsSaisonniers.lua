SystemeEvenementsSaisonniers = {}

function SystemeEvenementsSaisonniers:StartSeasonalEvent(eventName, season)
    print("Starting seasonal event '" .. eventName .. "' for the " .. season .. " season.")
end

function SystemeEvenementsSaisonniers:EndSeasonalEvent(eventName)
    print("Seasonal event '" .. eventName .. "' has concluded.")
end

return SystemeEvenementsSaisonniers
