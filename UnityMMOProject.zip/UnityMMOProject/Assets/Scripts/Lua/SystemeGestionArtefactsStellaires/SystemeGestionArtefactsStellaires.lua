SystemeGestionArtefactsStellaires = {}

function SystemeGestionArtefactsStellaires:DiscoverStellarArtifact(player, artifactName)
    print(player .. " discovers a stellar artifact: " .. artifactName)
end

function SystemeGestionArtefactsStellaires:UseStellarArtifact(player, artifactName)
    print(player .. " uses the stellar artifact: " .. artifactName)
end

return SystemeGestionArtefactsStellaires
