SystemeGestionRunesEnchantements = {}

function SystemeGestionRunesEnchantements:ApplyRune(player, item, rune)
    print(player .. " applies the rune " .. rune .. " to " .. item)
end

function SystemeGestionRunesEnchantements:EnchantWithAdvancedEffect(player, item, effect)
    print(player .. " enchants " .. item .. " with the effect: " .. effect)
end

return SystemeGestionRunesEnchantements
