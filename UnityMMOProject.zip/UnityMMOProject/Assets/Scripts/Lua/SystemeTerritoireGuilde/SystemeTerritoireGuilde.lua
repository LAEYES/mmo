SystemeTerritoireGuilde = {}

function SystemeTerritoireGuilde:ClaimTerritory(guild, territory)
    print(guild .. " has claimed territory: " .. territory)
end

function SystemeTerritoireGuilde:RelinquishTerritory(guild, territory)
    print(guild .. " has relinquished territory: " .. territory)
end

return SystemeTerritoireGuilde
