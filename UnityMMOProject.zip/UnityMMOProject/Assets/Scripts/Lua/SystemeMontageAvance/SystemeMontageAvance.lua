SystemeMontageAvance = {}

function SystemeMontageAvance:SummonMount(player, mount)
    print(player .. " summons " .. mount)
end

function SystemeMontageAvance:Dismount(player)
    print(player .. " dismounts")
end

return SystemeMontageAvance
