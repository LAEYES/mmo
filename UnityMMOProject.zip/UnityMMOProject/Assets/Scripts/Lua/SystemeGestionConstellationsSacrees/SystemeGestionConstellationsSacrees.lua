SystemeGestionConstellationsSacrees = {}

function SystemeGestionConstellationsSacrees:AlignWithConstellation(player, constellationName)
    print(player .. " aligns with the sacred constellation: " .. constellationName)
end

function SystemeGestionConstellationsSacrees:ReceiveConstellationBlessing(player, constellationName)
    print(player .. " receives a blessing from the constellation: " .. constellationName)
end

return SystemeGestionConstellationsSacrees
