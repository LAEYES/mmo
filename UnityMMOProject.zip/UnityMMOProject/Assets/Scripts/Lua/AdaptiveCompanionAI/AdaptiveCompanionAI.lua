AdaptiveCompanionAI = {}

function AdaptiveCompanionAI:FollowPlayer(player)
    print("Companion follows " .. player)
end

function AdaptiveCompanionAI:AssistInCombat(target)
    print("Companion assists in combat against " .. target)
end

return AdaptiveCompanionAI
