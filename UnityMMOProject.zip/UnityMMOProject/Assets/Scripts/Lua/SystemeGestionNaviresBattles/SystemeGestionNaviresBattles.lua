SystemeGestionNaviresBattles = {}

function SystemeGestionNaviresBattles:AcquireShip(player, shipType)
    print(player .. " acquires a ship: " .. shipType)
end

function SystemeGestionNaviresBattles:EngageInNavalBattle(player, enemyShip)
    print(player .. " engages in a naval battle with " .. enemyShip)
end

return SystemeGestionNaviresBattles
