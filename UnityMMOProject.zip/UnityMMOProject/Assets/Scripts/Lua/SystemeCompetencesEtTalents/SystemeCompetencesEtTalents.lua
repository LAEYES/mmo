SystemeCompetencesEtTalents = {}

function SystemeCompetencesEtTalents:LearnSkill(player, skill)
    print(player .. " learns a new skill: " .. skill)
end

function SystemeCompetencesEtTalents:UpgradeTalent(player, talent)
    print(player .. " upgrades talent: " .. talent)
end

return SystemeCompetencesEtTalents
