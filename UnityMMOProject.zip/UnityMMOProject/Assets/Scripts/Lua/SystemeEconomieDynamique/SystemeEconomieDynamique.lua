SystemeEconomieDynamique = {}

function SystemeEconomieDynamique:BuyItem(player, item, price)
    print(player .. " buys " .. item .. " for " .. price .. " coins")
end

function SystemeEconomieDynamique:SellItem(player, item, price)
    print(player .. " sells " .. item .. " for " .. price .. " coins")
end

function SystemeEconomieDynamique:UpdateMarketPrice(item, newPrice)
    print("Market price for " .. item .. " updated to " .. newPrice .. " coins")
end

return SystemeEconomieDynamique
