SystemeGestionMiniJeux = {}

function SystemeGestionMiniJeux:StartMiniGame(player, gameName)
    print(player .. " starts playing mini-game: " .. gameName)
end

function SystemeGestionMiniJeux:CompleteMiniGame(player, gameName)
    print(player .. " completes the mini-game: " .. gameName)
end

return SystemeGestionMiniJeux
