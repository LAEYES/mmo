SystemeGestionAlliancesInterGuildes = {}

function SystemeGestionAlliancesInterGuildes:FormAlliance(guild1, guild2)
    print("Guild " .. guild1 .. " has formed an alliance with " .. guild2)
end

function SystemeGestionAlliancesInterGuildes:BreakAlliance(guild1, guild2)
    print("Alliance between guild " .. guild1 .. " and guild " .. guild2 .. " has been broken")
end

return SystemeGestionAlliancesInterGuildes
