SystemeEconomie = {}

function SystemeEconomie:BuyItem(player, itemID, price)
    print(player .. " buys item with ID " .. itemID .. " for " .. price .. " gold.")
end

function SystemeEconomie:SellItem(player, itemID, price)
    print(player .. " sells item with ID " .. itemID .. " for " .. price .. " gold.")
end

return SystemeEconomie
