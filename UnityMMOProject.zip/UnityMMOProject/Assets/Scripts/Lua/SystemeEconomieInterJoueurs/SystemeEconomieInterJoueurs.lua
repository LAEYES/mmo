SystemeEconomieInterJoueurs = {}

function SystemeEconomieInterJoueurs:Trade(player1, player2, item)
    print(player1 .. " trades " .. item .. " with " .. player2)
end

function SystemeEconomieInterJoueurs:StartAuction(player, item, startPrice)
    print(player .. " starts an auction for " .. item .. " at " .. startPrice .. " coins")
end

function SystemeEconomieInterJoueurs:LendItem(player1, player2, item, duration)
    print(player1 .. " lends " .. item .. " to " .. player2 .. " for " .. duration .. " days")
end

return SystemeEconomieInterJoueurs
