SystemeGestionArtefactsAntiques = {}

function SystemeGestionArtefactsAntiques:DiscoverAncientArtifact(player, artifactName)
    print(player .. " discovers an ancient artifact: " .. artifactName)
end

function SystemeGestionArtefactsAntiques:ActivateAncientArtifact(player, artifactName)
    print(player .. " activates the ancient artifact: " .. artifactName)
end

return SystemeGestionArtefactsAntiques
