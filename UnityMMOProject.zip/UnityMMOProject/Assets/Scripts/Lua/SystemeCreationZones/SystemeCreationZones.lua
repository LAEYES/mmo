SystemeCreationZones = {}

function SystemeCreationZones:CreateZone(zoneName, zoneType)
    print("Creating zone: " .. zoneName .. " of type " .. zoneType)
end

function SystemeCreationZones:SetZoneAttributes(zoneName, attributes)
    print("Setting attributes for zone " .. zoneName)
    for key, value in pairs(attributes) do
        print(key .. ": " .. value)
    end
end

return SystemeCreationZones
