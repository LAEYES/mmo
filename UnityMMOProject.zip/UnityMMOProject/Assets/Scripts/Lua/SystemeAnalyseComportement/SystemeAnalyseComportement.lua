SystemeAnalyseComportement = {}

function SystemeAnalyseComportement:TrackPlayerAction(player, action)
    print(player .. " performed action: " .. action)
end

function SystemeAnalyseComportement:FlagSuspiciousActivity(player)
    print("Suspicious activity flagged for player: " .. player)
end

return SystemeAnalyseComportement
