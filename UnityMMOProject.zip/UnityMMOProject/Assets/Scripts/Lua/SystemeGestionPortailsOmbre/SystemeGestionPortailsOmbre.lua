SystemeGestionPortailsOmbre = {}

function SystemeGestionPortailsOmbre:OpenShadowPortal(player, portalName)
    print(player .. " opens a shadow portal to: " .. portalName)
end

function SystemeGestionPortailsOmbre:TravelThroughPortal(player, destination)
    print(player .. " travels through the shadow portal to: " .. destination)
end

return SystemeGestionPortailsOmbre
