SystemeGestionCitadellesCelestes = {}

function SystemeGestionCitadellesCelestes:VisitCelestialCitadel(player, citadelName)
    print(player .. " visits the celestial citadel: " .. citadelName)
end

function SystemeGestionCitadellesCelestes:ReceiveDivineBlessing(player, blessingType)
    print(player .. " receives a divine blessing of type: " .. blessingType)
end

return SystemeGestionCitadellesCelestes
