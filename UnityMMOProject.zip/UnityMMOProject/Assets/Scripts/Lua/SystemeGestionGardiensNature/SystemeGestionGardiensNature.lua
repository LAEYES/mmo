SystemeGestionGardiensNature = {}

function SystemeGestionGardiensNature:SummonNatureGuardian(player, guardianName)
    print(player .. " summons the nature guardian: " .. guardianName)
end

function SystemeGestionGardiensNature:ProtectEnvironment(player, areaName)
    print(player .. " uses a nature guardian to protect the area: " .. areaName)
end

return SystemeGestionGardiensNature
