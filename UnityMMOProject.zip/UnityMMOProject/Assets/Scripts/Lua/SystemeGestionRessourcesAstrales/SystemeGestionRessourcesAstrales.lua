SystemeGestionRessourcesAstrales = {}

function SystemeGestionRessourcesAstrales:CollectAstralResource(player, resourceType, amount)
    print(player .. " collects " .. amount .. " units of " .. resourceType .. " astral resource")
end

function SystemeGestionRessourcesAstrales:UseAstralResource(player, resourceType, amount)
    print(player .. " uses " .. amount .. " units of " .. resourceType .. " astral resource")
end

return SystemeGestionRessourcesAstrales
