SystemeGestionTempetesMagiques = {}

function SystemeGestionTempetesMagiques:EncounterMagicalStorm(player, stormType)
    print(player .. " encounters a magical storm: " .. stormType)
end

function SystemeGestionTempetesMagiques:HarvestStormEnergy(player, stormType, amount)
    print(player .. " harvests " .. amount .. " units of energy from the " .. stormType .. " storm")
end

return SystemeGestionTempetesMagiques
