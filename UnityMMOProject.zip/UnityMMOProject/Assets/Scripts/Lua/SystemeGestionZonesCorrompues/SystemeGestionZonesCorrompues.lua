SystemeGestionZonesCorrompues = {}

function SystemeGestionZonesCorrompues:EnterCorruptedZone(player, zoneName)
    print(player .. " enters the corrupted zone: " .. zoneName)
end

function SystemeGestionZonesCorrompues:PurifyCorruptedZone(player, zoneName)
    print(player .. " purifies the corrupted zone: " .. zoneName)
end

return SystemeGestionZonesCorrompues
