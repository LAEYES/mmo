SystemeGestionFragmentsAme = {}

function SystemeGestionFragmentsAme:CollectSoulFragment(player, fragmentType)
    print(player .. " collects a soul fragment of type: " .. fragmentType)
end

function SystemeGestionFragmentsAme:FuseSoulFragments(player)
    print(player .. " fuses collected soul fragments to gain spiritual power")
end

return SystemeGestionFragmentsAme
