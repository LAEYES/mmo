SystemeLogistiqueEconomique = {}

function SystemeLogistiqueEconomique:TradeItem(player1, player2, item)
    print(player1 .. " trades " .. item .. " with " .. player2)
end

function SystemeLogistiqueEconomique:ApplyGuildTax(player, amount)
    print("A guild tax of " .. amount .. " is applied to " .. player)
end

function SystemeLogistiqueEconomique:ExchangeRareItem(player, rareItem)
    print(player .. " exchanges a rare item: " .. rareItem)
end

return SystemeLogistiqueEconomique
