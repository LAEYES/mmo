-- Map and navigation system
Map = {
    regions = {}
}

function Map:AddRegion(name, description, npcList)
    local region = {
        name = name,
        description = description,
        npcs = npcList
    }
    table.insert(self.regions, region)
    print('Region ' .. name .. ' added to the map.')
end

function Map:ListRegions()
    for _, region in ipairs(self.regions) do
        print('Region: ' .. region.name .. ' - ' .. region.description)
        for _, npc in ipairs(region.npcs) do
            print('  - NPC: ' .. npc.name)
        end
    end
end
