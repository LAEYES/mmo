SystemeGestionPortailsNeant = {}

function SystemeGestionPortailsNeant:OpenVoidPortal(player, portalName)
    print(player .. " opens a void portal to: " .. portalName)
end

function SystemeGestionPortailsNeant:CloseVoidPortal(player, portalName)
    print(player .. " closes the void portal to: " .. portalName)
end

return SystemeGestionPortailsNeant
