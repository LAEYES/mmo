SystemeGestionRunesTeleportation = {}

function SystemeGestionRunesTeleportation:DiscoverTeleportationRune(player, runeName)
    print(player .. " discovers a teleportation rune: " .. runeName)
end

function SystemeGestionRunesTeleportation:UseRuneTeleport(player, destination)
    print(player .. " teleports to destination: " .. destination)
end

return SystemeGestionRunesTeleportation
