SystemeGestionCristauxChaos = {}

function SystemeGestionCristauxChaos:DiscoverChaosCrystal(player, crystalType)
    print(player .. " discovers a chaos crystal of type: " .. crystalType)
end

function SystemeGestionCristauxChaos:ActivateCrystalPower(player, crystalType)
    print(player .. " activates the power of the chaos crystal: " .. crystalType)
end

return SystemeGestionCristauxChaos
