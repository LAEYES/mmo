SystemeGestionCristauxMana = {}

function SystemeGestionCristauxMana:CollectManaCrystal(player, crystalType)
    print(player .. " collects a mana crystal of type: " .. crystalType)
end

function SystemeGestionCristauxMana:UseManaCrystal(player, crystalType)
    print(player .. " uses the mana crystal of type: " .. crystalType)
end

return SystemeGestionCristauxMana
