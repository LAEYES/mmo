SystemeGestionEpreuves = {}

function SystemeGestionEpreuves:StartTrial(player, trialName)
    print(player .. " starts the trial: " .. trialName)
end

function SystemeGestionEpreuves:CompleteTrial(player, trialName)
    print(player .. " completes the trial: " .. trialName)
end

return SystemeGestionEpreuves
