SystemeGestionMeteoresMystiques = {}

function SystemeGestionMeteoresMystiques:DiscoverMeteor(player, meteorType)
    print(player .. " discovers a mystical meteor of type: " .. meteorType)
end

function SystemeGestionMeteoresMystiques:HarvestMeteorResources(player, meteorType, resource)
    print(player .. " harvests " .. resource .. " from the meteor of type: " .. meteorType)
end

return SystemeGestionMeteoresMystiques
