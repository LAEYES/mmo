SystemeGestionDefisOmbre = {}

function SystemeGestionDefisOmbre:StartShadowChallenge(player, challengeName)
    print(player .. " starts the shadow challenge: " .. challengeName)
end

function SystemeGestionDefisOmbre:CompleteShadowChallenge(player, challengeName)
    print(player .. " completes the shadow challenge: " .. challengeName)
end

return SystemeGestionDefisOmbre
