SystemeCompetencesTalents = {}

function SystemeCompetencesTalents:LearnSkill(player, skill)
    print(player .. " has learned the skill: " .. skill)
end

function SystemeCompetencesTalents:UpgradeTalent(player, talent)
    print(player .. " has upgraded the talent: " .. talent)
end

return SystemeCompetencesTalents
