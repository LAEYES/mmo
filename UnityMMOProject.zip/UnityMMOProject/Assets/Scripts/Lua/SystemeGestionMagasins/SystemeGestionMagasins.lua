SystemeGestionMagasins = {}

function SystemeGestionMagasins:AddItemToShop(shopName, item, price)
    print("Item " .. item .. " added to " .. shopName .. " for " .. price .. " coins.")
end

function SystemeGestionMagasins:SellItem(player, shopName, item)
    print(player .. " purchases " .. item .. " from " .. shopName)
end

return SystemeGestionMagasins
