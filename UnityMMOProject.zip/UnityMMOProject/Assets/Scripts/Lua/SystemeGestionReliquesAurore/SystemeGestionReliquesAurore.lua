SystemeGestionReliquesAurore = {}

function SystemeGestionReliquesAurore:FindDawnRelic(player, relicName)
    print(player .. " discovers a dawn relic: " .. relicName)
end

function SystemeGestionReliquesAurore:ActivateRelicPower(player, relicName)
    print(player .. " activates the dawn relic: " .. relicName .. " and gains morning power")
end

return SystemeGestionReliquesAurore
