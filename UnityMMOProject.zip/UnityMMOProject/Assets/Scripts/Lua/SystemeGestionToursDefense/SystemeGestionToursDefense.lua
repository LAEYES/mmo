SystemeGestionToursDefense = {}

function SystemeGestionToursDefense:BuildTower(player, location, towerType)
    print(player .. " builds a " .. towerType .. " tower at " .. location)
end

function SystemeGestionToursDefense:UpgradeTower(player, towerType, upgradeLevel)
    print(player .. " upgrades the " .. towerType .. " tower to level " .. upgradeLevel)
end

return SystemeGestionToursDefense
