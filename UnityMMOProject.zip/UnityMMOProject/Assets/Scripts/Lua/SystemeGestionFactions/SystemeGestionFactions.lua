SystemeGestionFactions = {}

function SystemeGestionFactions:JoinFaction(player, factionName)
    print(player .. " joins the faction: " .. factionName)
end

function SystemeGestionFactions:EarnFactionPoints(player, factionName, points)
    print(player .. " earns " .. points .. " points for faction: " .. factionName)
end

return SystemeGestionFactions
