SystemeTalentsAvances = {}

function SystemeTalentsAvances:UnlockTalent(player, talent)
    print(player .. " unlocks the advanced talent: " .. talent)
end

function SystemeTalentsAvances:UpgradeTalent(player, talent)
    print(player .. " upgrades the talent: " .. talent)
end

return SystemeTalentsAvances
