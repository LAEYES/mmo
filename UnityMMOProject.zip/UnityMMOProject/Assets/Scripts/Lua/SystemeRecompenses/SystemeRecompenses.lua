SystemeRecompenses = {}

function SystemeRecompenses:GrantReward(player, reward)
    print(player .. " has received reward: " .. reward)
end

function SystemeRecompenses:TrackAchievements(player, achievement)
    print(player .. " unlocked achievement: " .. achievement)
end

return SystemeRecompenses
