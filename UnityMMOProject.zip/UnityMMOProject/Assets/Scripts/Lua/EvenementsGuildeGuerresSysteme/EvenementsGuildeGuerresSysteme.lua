EvenementsGuildeGuerresSysteme = {}

function EvenementsGuildeGuerresSysteme:StartGuildEvent(guild, eventName)
    print("Guild " .. guild .. " starts event: " .. eventName)
end

function EvenementsGuildeGuerresSysteme:EndGuildEvent(guild, eventName)
    print("Guild " .. guild .. " ends event: " .. eventName)
end

return EvenementsGuildeGuerresSysteme
