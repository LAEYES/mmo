SystemeGestionReliquesChaos = {}

function SystemeGestionReliquesChaos:DiscoverChaosRelic(player, relicName)
    print(player .. " discovers a chaos relic: " .. relicName)
end

function SystemeGestionReliquesChaos:UnleashChaosPower(player, powerType)
    print(player .. " unleashes the power of the chaos relic: " .. powerType)
end

return SystemeGestionReliquesChaos
