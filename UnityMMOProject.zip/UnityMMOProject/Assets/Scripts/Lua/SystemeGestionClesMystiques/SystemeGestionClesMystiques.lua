SystemeGestionClesMystiques = {}

function SystemeGestionClesMystiques:FindMysticKey(player, keyName)
    print(player .. " finds a mystic key: " .. keyName)
end

function SystemeGestionClesMystiques:UseMysticKey(player, lockType)
    print(player .. " uses the mystic key to unlock: " .. lockType)
end

return SystemeGestionClesMystiques
