SystemeGestionForgesCelestes = {}

function SystemeGestionForgesCelestes:AccessCelestialForge(player, forgeName)
    print(player .. " accesses the celestial forge: " .. forgeName)
end

function SystemeGestionForgesCelestes:ForgeCelestialWeapon(player, weaponType)
    print(player .. " forges a celestial weapon of type: " .. weaponType)
end

return SystemeGestionForgesCelestes
