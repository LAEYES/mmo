SystemeGestionDonjonsGroupe = {}

function SystemeGestionDonjonsGroupe:EnterDungeon(playerGroup, dungeonName)
    print("The group led by " .. playerGroup[1] .. " enters the dungeon: " .. dungeonName)
end

function SystemeGestionDonjonsGroupe:CompleteDungeon(playerGroup, dungeonName)
    print("The group led by " .. playerGroup[1] .. " has completed the dungeon: " .. dungeonName)
end

return SystemeGestionDonjonsGroupe
