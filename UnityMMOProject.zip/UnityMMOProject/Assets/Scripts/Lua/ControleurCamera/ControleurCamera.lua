ControleurCamera = {}

function ControleurCamera:SetView(viewType)
    print("Setting camera view to " .. viewType)
end

function ControleurCamera:ZoomIn()
    print("Camera zooms in")
end

function ControleurCamera:ZoomOut()
    print("Camera zooms out")
end

return ControleurCamera
