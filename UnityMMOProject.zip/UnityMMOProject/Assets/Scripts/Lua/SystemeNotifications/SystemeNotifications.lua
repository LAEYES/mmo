SystemeNotifications = {}

function SystemeNotifications:SendNotification(player, message)
    print("Notification for " .. player .. ": " .. message)
end

function SystemeNotifications:Broadcast(message)
    print("Broadcast message to all players: " .. message)
end

return SystemeNotifications
