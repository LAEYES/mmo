SystemeGestionArmesMythiques = {}

function SystemeGestionArmesMythiques:FindMythicalWeapon(player, weaponName)
    print(player .. " finds a mythical weapon: " .. weaponName)
end

function SystemeGestionArmesMythiques:UseWeaponPower(player, powerType)
    print(player .. " uses the power of the mythical weapon: " .. powerType)
end

return SystemeGestionArmesMythiques
