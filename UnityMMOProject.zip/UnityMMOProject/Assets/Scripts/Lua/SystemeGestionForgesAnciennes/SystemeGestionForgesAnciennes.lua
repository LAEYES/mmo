SystemeGestionForgesAnciennes = {}

function SystemeGestionForgesAnciennes:AccessAncientForge(player, forgeName)
    print(player .. " accesses the ancient forge: " .. forgeName)
end

function SystemeGestionForgesAnciennes:ForgeWeapon(player, weaponName)
    print(player .. " forges a weapon using the ancient forge: " .. weaponName)
end

return SystemeGestionForgesAnciennes
