SystemeGestionPeche = {}

function SystemeGestionPeche:StartFishing(player, location)
    print(player .. " starts fishing at " .. location)
end

function SystemeGestionPeche:CatchFish(player, fish)
    print(player .. " catches a fish: " .. fish)
end

function SystemeGestionPeche:EndFishing(player)
    print(player .. " stops fishing")
end

return SystemeGestionPeche
