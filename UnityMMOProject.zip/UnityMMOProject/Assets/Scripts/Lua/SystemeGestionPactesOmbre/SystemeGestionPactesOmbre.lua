SystemeGestionPactesOmbre = {}

function SystemeGestionPactesOmbre:FormShadowPact(player, entityName)
    print(player .. " forms a shadow pact with " .. entityName)
end

function SystemeGestionPactesOmbre:InvokeShadowPower(player, powerName)
    print(player .. " invokes the shadow power: " .. powerName)
end

return SystemeGestionPactesOmbre
