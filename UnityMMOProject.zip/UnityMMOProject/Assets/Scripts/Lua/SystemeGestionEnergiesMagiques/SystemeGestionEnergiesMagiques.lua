SystemeGestionEnergiesMagiques = {}

function SystemeGestionEnergiesMagiques:CollectMagicEnergy(player, energyType, amount)
    print(player .. " collects " .. amount .. " units of " .. energyType .. " magic energy")
end

function SystemeGestionEnergiesMagiques:UseMagicEnergy(player, energyType, amount)
    print(player .. " uses " .. amount .. " units of " .. energyType .. " magic energy")
end

return SystemeGestionEnergiesMagiques
