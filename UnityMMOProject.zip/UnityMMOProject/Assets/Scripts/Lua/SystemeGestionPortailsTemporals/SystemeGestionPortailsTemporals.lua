SystemeGestionPortailsTemporals = {}

function SystemeGestionPortailsTemporals:OpenTemporalPortal(player, era)
    print(player .. " opens a temporal portal to the era: " .. era)
end

function SystemeGestionPortailsTemporals:TravelToEra(player, destination)
    print(player .. " travels to the era: " .. destination)
end

return SystemeGestionPortailsTemporals
