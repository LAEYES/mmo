SystemeEvenementsAleatoires = {}

function SystemeEvenementsAleatoires:TriggerEvent(eventName)
    print("Random event triggered: " .. eventName)
end

function SystemeEvenementsAleatoires:ResolveEvent(eventName)
    print("Random event resolved: " .. eventName)
end

return SystemeEvenementsAleatoires
