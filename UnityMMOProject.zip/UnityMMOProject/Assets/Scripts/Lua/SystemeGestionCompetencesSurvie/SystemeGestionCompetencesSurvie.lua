SystemeGestionCompetencesSurvie = {}

function SystemeGestionCompetencesSurvie:Hunt(player, animal)
    print(player .. " hunts a " .. animal)
end

function SystemeGestionCompetencesSurvie:GatherResources(player, resource)
    print(player .. " gathers " .. resource)
end

function SystemeGestionCompetencesSurvie:BuildShelter(player)
    print(player .. " builds a shelter")
end

return SystemeGestionCompetencesSurvie
