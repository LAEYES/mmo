SystemeGestionInstancesDonjon = {}

function SystemeGestionInstancesDonjon:CreateDungeonInstance(player, dungeonName)
    print("Creating dungeon instance '" .. dungeonName .. "' for " .. player)
end

function SystemeGestionInstancesDonjon:EnterDungeon(player, dungeonName)
    print(player .. " enters the dungeon: " .. dungeonName)
end

function SystemeGestionInstancesDonjon:CompleteDungeon(player, dungeonName)
    print(player .. " has completed the dungeon: " .. dungeonName)
end

return SystemeGestionInstancesDonjon
