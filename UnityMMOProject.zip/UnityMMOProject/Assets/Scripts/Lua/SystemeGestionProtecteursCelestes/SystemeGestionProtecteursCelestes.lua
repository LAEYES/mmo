SystemeGestionProtecteursCelestes = {}

function SystemeGestionProtecteursCelestes:SummonCelestialGuardian(player, guardianName)
    print(player .. " summons the celestial guardian: " .. guardianName)
end

function SystemeGestionProtecteursCelestes:ReceiveGuardianBlessing(player, guardianName)
    print(player .. " receives a blessing from the celestial guardian: " .. guardianName)
end

return SystemeGestionProtecteursCelestes
