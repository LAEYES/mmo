-- Objective system for managing missions and objectives
ObjectiveSystem = {
    objectives = {}
}

function ObjectiveSystem:AddObjective(description)
    local objective = {
        description = description,
        isComplete = false
    }
    table.insert(self.objectives, objective)
    print('Objective added: ' .. description)
end

function ObjectiveSystem:CompleteObjective(description)
    for _, objective in ipairs(self.objectives) do
        if objective.description == description then
            objective.isComplete = true
            print('Objective completed: ' .. description)
            break
        end
    end
end

function ObjectiveSystem:ListObjectives()
    print('Current objectives:')
    for _, objective in ipairs(self.objectives) do
        local status = objective.isComplete and '[Complete]' or '[Incomplete]'
        print('- ' .. objective.description .. ' ' .. status)
    end
end
