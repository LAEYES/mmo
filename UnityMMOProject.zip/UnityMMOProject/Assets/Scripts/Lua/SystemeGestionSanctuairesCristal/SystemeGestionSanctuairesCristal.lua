SystemeGestionSanctuairesCristal = {}

function SystemeGestionSanctuairesCristal:EnterCrystalSanctuary(player, sanctuaryName)
    print(player .. " enters the crystal sanctuary: " .. sanctuaryName)
end

function SystemeGestionSanctuairesCristal:CollectCrystalBlessing(player, crystalType)
    print(player .. " collects a crystal blessing of type: " .. crystalType)
end

return SystemeGestionSanctuairesCristal
