SystemeGestionSpheresSagesse = {}

function SystemeGestionSpheresSagesse:FindWisdomSphere(player, sphereType)
    print(player .. " finds a wisdom sphere of type: " .. sphereType)
end

function SystemeGestionSpheresSagesse:UseSpherePower(player, sphereType)
    print(player .. " uses the wisdom sphere for clairvoyance of type: " .. sphereType)
end

return SystemeGestionSpheresSagesse
