SystemeGestionGardiensAnciens = {}

function SystemeGestionGardiensAnciens:EncounterGuardian(player, guardianName)
    print(player .. " encounters the ancient guardian: " .. guardianName)
end

function SystemeGestionGardiensAnciens:DefeatGuardian(player, guardianName)
    print(player .. " defeats the ancient guardian: " .. guardianName)
end

return SystemeGestionGardiensAnciens
