SystemeSauvegardeAutomatique = {}

function SystemeSauvegardeAutomatique:AutoSave(player)
    print("Auto-saving data for player: " .. player)
end

function SystemeSauvegardeAutomatique:ManualSave(player)
    print("Manually saving data for player: " .. player)
end

return SystemeSauvegardeAutomatique
