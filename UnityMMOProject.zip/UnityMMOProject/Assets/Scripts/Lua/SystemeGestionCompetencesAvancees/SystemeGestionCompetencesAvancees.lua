SystemeGestionCompetencesAvancees = {}

function SystemeGestionCompetencesAvancees:UnlockSkill(player, skillName)
    print(player .. " has unlocked a new skill: " .. skillName)
end

function SystemeGestionCompetencesAvancees:UpgradeSkill(player, skillName)
    print(player .. " has upgraded the skill: " .. skillName)
end

return SystemeGestionCompetencesAvancees
