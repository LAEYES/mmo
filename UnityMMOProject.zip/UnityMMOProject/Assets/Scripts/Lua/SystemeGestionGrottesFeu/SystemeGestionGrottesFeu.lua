SystemeGestionGrottesFeu = {}

function SystemeGestionGrottesFeu:EnterFireCave(player, caveName)
    print(player .. " enters the fire cave: " .. caveName)
end

function SystemeGestionGrottesFeu:CollectRareResource(player, resourceType)
    print(player .. " collects a rare resource of type: " .. resourceType .. " from the fire cave")
end

return SystemeGestionGrottesFeu
