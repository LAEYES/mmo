SystemeEnregistrementSucces = {}

function SystemeEnregistrementSucces:UnlockAchievement(player, achievement)
    print(player .. " unlocked achievement: " .. achievement)
end

function SystemeEnregistrementSucces:ListAchievements(player)
    print("Listing all achievements for " .. player)
end

return SystemeEnregistrementSucces
