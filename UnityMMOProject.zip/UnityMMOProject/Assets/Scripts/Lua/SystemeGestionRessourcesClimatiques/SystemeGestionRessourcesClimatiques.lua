SystemeGestionRessourcesClimatiques = {}

function SystemeGestionRessourcesClimatiques:CollectClimateResource(player, climateType, resource)
    print(player .. " collects " .. resource .. " from a " .. climateType .. " environment")
end

function SystemeGestionRessourcesClimatiques:ConvertResource(player, resource, newForm)
    print(player .. " converts " .. resource .. " into " .. newForm)
end

return SystemeGestionRessourcesClimatiques
