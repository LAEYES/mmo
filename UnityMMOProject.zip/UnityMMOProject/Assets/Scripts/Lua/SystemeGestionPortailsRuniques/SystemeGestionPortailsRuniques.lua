SystemeGestionPortailsRuniques = {}

function SystemeGestionPortailsRuniques:OpenRunicPortal(player, location)
    print(player .. " opens a runic portal to: " .. location)
end

function SystemeGestionPortailsRuniques:CloseRunicPortal(player, location)
    print(player .. " closes the runic portal to: " .. location)
end

return SystemeGestionPortailsRuniques
