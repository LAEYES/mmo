SystemeGestionForgesMystiques = {}

function SystemeGestionForgesMystiques:ForgeItem(player, itemName, material)
    print(player .. " forges " .. itemName .. " using " .. material .. " at the mystic forge")
end

function SystemeGestionForgesMystiques:UpgradeForge(player, forgeLevel)
    print(player .. " upgrades the mystic forge to level " .. forgeLevel)
end

return SystemeGestionForgesMystiques
