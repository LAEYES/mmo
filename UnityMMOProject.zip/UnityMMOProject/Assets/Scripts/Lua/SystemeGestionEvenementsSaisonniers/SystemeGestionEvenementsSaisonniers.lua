SystemeGestionEvenementsSaisonniers = {}

function SystemeGestionEvenementsSaisonniers:StartSeasonalEvent(eventName, season)
    print("Seasonal event '" .. eventName .. "' has started for " .. season)
end

function SystemeGestionEvenementsSaisonniers:CompleteSeasonalEvent(player, eventName)
    print(player .. " completes the seasonal event: " .. eventName)
end

return SystemeGestionEvenementsSaisonniers
