SystemeGestionAlliesFantomatiques = {}

function SystemeGestionAlliesFantomatiques:SummonPhantomAlly(player, allyName)
    print(player .. " summons the phantom ally: " .. allyName)
end

function SystemeGestionAlliesFantomatiques:ReceiveAllyBoost(player, boostType)
    print(player .. " receives a boost from the phantom ally: " .. boostType)
end

return SystemeGestionAlliesFantomatiques
