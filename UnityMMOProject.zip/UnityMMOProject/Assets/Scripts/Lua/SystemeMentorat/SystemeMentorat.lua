SystemeMentorat = {}

function SystemeMentorat:AssignMentor(mentor, mentee)
    print(mentor .. " is now mentoring " .. mentee)
end

function SystemeMentorat:TrackMentorshipProgress(mentor, mentee, progress)
    print("Mentorship progress for " .. mentee .. " under " .. mentor .. ": " .. progress .. "%")
end

return SystemeMentorat
