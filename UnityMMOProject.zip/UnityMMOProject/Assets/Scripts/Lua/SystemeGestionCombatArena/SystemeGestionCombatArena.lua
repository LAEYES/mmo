SystemeGestionCombatArena = {}

function SystemeGestionCombatArena:StartArenaMatch(player1, player2)
    print(player1 .. " and " .. player2 .. " are starting an arena match")
end

function SystemeGestionCombatArena:DeclareWinner(winner)
    print(winner .. " has won the arena match!")
end

return SystemeGestionCombatArena
