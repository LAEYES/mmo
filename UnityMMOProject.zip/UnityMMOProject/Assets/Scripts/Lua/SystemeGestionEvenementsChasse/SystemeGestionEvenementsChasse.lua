SystemeGestionEvenementsChasse = {}

function SystemeGestionEvenementsChasse:StartHuntingEvent(eventName, location)
    print("Hunting event '" .. eventName .. "' has started at " .. location)
end

function SystemeGestionEvenementsChasse:CaptureCreature(player, creature)
    print(player .. " captures the creature: " .. creature)
end

return SystemeGestionEvenementsChasse
