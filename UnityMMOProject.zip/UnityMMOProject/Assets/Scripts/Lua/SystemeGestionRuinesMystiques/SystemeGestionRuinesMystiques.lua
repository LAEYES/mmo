SystemeGestionRuinesMystiques = {}

function SystemeGestionRuinesMystiques:EnterMysticRuins(player, ruinsName)
    print(player .. " enters the mystic ruins: " .. ruinsName)
end

function SystemeGestionRuinesMystiques:DiscoverAncientRelic(player, relicName)
    print(player .. " discovers an ancient relic: " .. relicName)
end

return SystemeGestionRuinesMystiques
