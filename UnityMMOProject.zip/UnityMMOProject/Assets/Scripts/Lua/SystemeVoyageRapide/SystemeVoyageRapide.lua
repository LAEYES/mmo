SystemeVoyageRapide = {}

function SystemeVoyageRapide:TravelToLocation(player, location)
    print(player .. " fast travels to " .. location)
end

return SystemeVoyageRapide
