SystemeGestionAvantPostes = {}

function SystemeGestionAvantPostes:CaptureOutpost(player, outpostName)
    print(player .. " captures the outpost: " .. outpostName)
end

function SystemeGestionAvantPostes:UpgradeOutpost(player, outpostName)
    print(player .. " upgrades the outpost: " .. outpostName)
end

return SystemeGestionAvantPostes
