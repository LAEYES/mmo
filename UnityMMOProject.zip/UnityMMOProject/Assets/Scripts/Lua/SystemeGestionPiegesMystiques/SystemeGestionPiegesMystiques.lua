SystemeGestionPiegesMystiques = {}

function SystemeGestionPiegesMystiques:PlaceMysticTrap(player, trapType)
    print(player .. " places a mystic trap of type: " .. trapType)
end

function SystemeGestionPiegesMystiques:ActivateTrapEffect(player, trapType)
    print(player .. " activates the mystic trap effect of type: " .. trapType)
end

return SystemeGestionPiegesMystiques
