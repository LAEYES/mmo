SystemeGestionPierresEther = {}

function SystemeGestionPierresEther:FindEtherStone(player, stoneType)
    print(player .. " finds an ether stone of type: " .. stoneType)
end

function SystemeGestionPierresEther:UseEtherPower(player, powerType)
    print(player .. " uses the ether stone's power: " .. powerType)
end

return SystemeGestionPierresEther
