SystemeGestionTempetesFeu = {}

function SystemeGestionTempetesFeu:SummonFirestorm(player, stormType)
    print(player .. " summons a firestorm of type: " .. stormType)
end

function SystemeGestionTempetesFeu:ControlFirestorm(player, stormType)
    print(player .. " controls the firestorm of type: " .. stormType)
end

return SystemeGestionTempetesFeu
