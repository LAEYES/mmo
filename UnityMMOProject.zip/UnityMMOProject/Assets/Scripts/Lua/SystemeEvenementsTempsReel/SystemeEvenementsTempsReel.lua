SystemeEvenementsTempsReel = {}

function SystemeEvenementsTempsReel:StartRealTimeEvent(eventName)
    print("Real-time event '" .. eventName .. "' has started")
end

function SystemeEvenementsTempsReel:EndRealTimeEvent(eventName)
    print("Real-time event '" .. eventName .. "' has ended")
end

return SystemeEvenementsTempsReel
