SystemeGestionEspritsProtecteurs = {}

function SystemeGestionEspritsProtecteurs:SummonGuardianSpirit(player, spiritName)
    print(player .. " summons a guardian spirit: " .. spiritName)
end

function SystemeGestionEspritsProtecteurs:ReceiveSpiritBlessing(player, blessingType)
    print(player .. " receives a blessing from the guardian spirit: " .. blessingType)
end

return SystemeGestionEspritsProtecteurs
