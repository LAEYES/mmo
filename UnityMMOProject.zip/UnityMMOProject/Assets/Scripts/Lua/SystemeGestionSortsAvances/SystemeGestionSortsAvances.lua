SystemeGestionSortsAvances = {}

function SystemeGestionSortsAvances:CastSpell(player, spellName)
    print(player .. " casts an advanced spell: " .. spellName)
end

function SystemeGestionSortsAvances:UpgradeSpell(player, spellName)
    print(player .. " upgrades the spell: " .. spellName)
end

return SystemeGestionSortsAvances
