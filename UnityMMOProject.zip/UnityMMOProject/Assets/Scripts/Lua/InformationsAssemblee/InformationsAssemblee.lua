InformationsAssemblee = {
    version = "1.0",
    author = "Your Name"
}

function InformationsAssemblee:GetInfo()
    print("Version: " .. self.version .. ", Author: " .. self.author)
end

return InformationsAssemblee
