SystemeGestionCompetencesSecretes = {}

function SystemeGestionCompetencesSecretes:LearnSecretSkill(player, skillName)
    print(player .. " learns a secret skill: " .. skillName)
end

function SystemeGestionCompetencesSecretes:UseSecretSkill(player, skillName)
    print(player .. " uses the secret skill: " .. skillName)
end

return SystemeGestionCompetencesSecretes
