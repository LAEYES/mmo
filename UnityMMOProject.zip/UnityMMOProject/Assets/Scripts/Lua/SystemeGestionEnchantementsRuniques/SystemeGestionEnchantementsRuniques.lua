SystemeGestionEnchantementsRuniques = {}

function SystemeGestionEnchantementsRuniques:DiscoverRune(player, runeName)
    print(player .. " discovers the rune: " .. runeName)
end

function SystemeGestionEnchantementsRuniques:EnchantItemWithRune(player, itemName, runeName)
    print(player .. " enchants " .. itemName .. " with the rune: " .. runeName)
end

return SystemeGestionEnchantementsRuniques
