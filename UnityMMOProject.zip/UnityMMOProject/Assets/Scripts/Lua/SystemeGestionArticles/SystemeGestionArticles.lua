SystemeGestionArticles = {}

function SystemeGestionArticles:AddToInventory(player, item)
    print(item .. " has been added to " .. player .. "'s inventory.")
end

function SystemeGestionArticles:EquipItem(player, item)
    print(player .. " equips " .. item)
end

function SystemeGestionArticles:EnhanceItem(player, item)
    print(player .. " enhances " .. item .. " to improve its power.")
end

return SystemeGestionArticles
