SystemeGestionServeurs = {}

function SystemeGestionServeurs:StartServer(serverName)
    print("Starting server: " .. serverName)
end

function SystemeGestionServeurs:ShutdownServer(serverName)
    print("Shutting down server: " .. serverName)
end

function SystemeGestionServeurs:MonitorServerHealth(serverName)
    print("Monitoring server health for: " .. serverName)
end

return SystemeGestionServeurs
