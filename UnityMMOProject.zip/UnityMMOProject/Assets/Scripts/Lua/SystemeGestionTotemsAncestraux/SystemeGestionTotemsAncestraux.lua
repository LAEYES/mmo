SystemeGestionTotemsAncestraux = {}

function SystemeGestionTotemsAncestraux:PlaceTotem(player, totemName)
    print(player .. " places an ancestral totem: " .. totemName)
end

function SystemeGestionTotemsAncestraux:InvokeTotemPower(player, totemName)
    print(player .. " invokes the power of the totem: " .. totemName)
end

return SystemeGestionTotemsAncestraux
