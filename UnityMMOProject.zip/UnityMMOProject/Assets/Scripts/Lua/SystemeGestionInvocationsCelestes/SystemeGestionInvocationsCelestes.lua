SystemeGestionInvocationsCelestes = {}

function SystemeGestionInvocationsCelestes:SummonCelestial(player, celestialName)
    print(player .. " summons the celestial entity: " .. celestialName)
end

function SystemeGestionInvocationsCelestes:DismissCelestial(player, celestialName)
    print(player .. " dismisses the celestial entity: " .. celestialName)
end

return SystemeGestionInvocationsCelestes
