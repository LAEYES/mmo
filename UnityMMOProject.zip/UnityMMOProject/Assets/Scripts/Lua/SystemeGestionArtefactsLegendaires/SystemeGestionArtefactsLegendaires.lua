SystemeGestionArtefactsLegendaires = {}

function SystemeGestionArtefactsLegendaires:FindLegendaryArtifact(player, artifactName)
    print(player .. " discovers a legendary artifact: " .. artifactName)
end

function SystemeGestionArtefactsLegendaires:ActivateArtifactPower(player, artifactName)
    print(player .. " activates the power of the legendary artifact: " .. artifactName)
end

return SystemeGestionArtefactsLegendaires
