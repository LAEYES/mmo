SystemeGestionLabyrinthesOubli = {}

function SystemeGestionLabyrinthesOubli:EnterLabyrinth(player, labyrinthName)
    print(player .. " enters the labyrinth of oblivion: " .. labyrinthName)
end

function SystemeGestionLabyrinthesOubli:SolveLabyrinthPuzzle(player, puzzleName)
    print(player .. " solves the puzzle: " .. puzzleName .. " in the labyrinth")
end

return SystemeGestionLabyrinthesOubli
