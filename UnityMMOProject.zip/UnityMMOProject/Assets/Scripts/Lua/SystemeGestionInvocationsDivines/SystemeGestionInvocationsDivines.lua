SystemeGestionInvocationsDivines = {}

function SystemeGestionInvocationsDivines:InvokeDeity(player, deityName)
    print(player .. " invokes the deity: " .. deityName)
end

function SystemeGestionInvocationsDivines:ReceiveDivineBlessing(player, blessingType)
    print(player .. " receives a divine blessing of type: " .. blessingType)
end

return SystemeGestionInvocationsDivines
