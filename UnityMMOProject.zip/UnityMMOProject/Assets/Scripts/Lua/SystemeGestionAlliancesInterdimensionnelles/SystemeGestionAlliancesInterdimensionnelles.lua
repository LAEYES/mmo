SystemeGestionAlliancesInterdimensionnelles = {}

function SystemeGestionAlliancesInterdimensionnelles:FormAlliance(player, dimension, allianceName)
    print(player .. " forms an alliance with the " .. allianceName .. " of dimension: " .. dimension)
end

function SystemeGestionAlliancesInterdimensionnelles:GainAllianceBenefit(player, dimension, benefit)
    print(player .. " gains the benefit '" .. benefit .. "' from the alliance in dimension: " .. dimension)
end

return SystemeGestionAlliancesInterdimensionnelles
