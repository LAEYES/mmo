SystemeAnalyseProgression = {}

function SystemeAnalyseProgression:TrackAchievement(player, achievement)
    print(player .. " achieves: " .. achievement)
end

function SystemeAnalyseProgression:UpdateStatistics(player, stat, value)
    print(player .. "'s " .. stat .. " updated to " .. value)
end

function SystemeAnalyseProgression:LevelMilestone(player, level)
    print(player .. " reaches milestone level: " .. level)
end

return SystemeAnalyseProgression
