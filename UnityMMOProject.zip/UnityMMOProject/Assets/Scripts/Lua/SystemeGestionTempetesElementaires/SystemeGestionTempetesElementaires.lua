SystemeGestionTempetesElementaires = {}

function SystemeGestionTempetesElementaires:SummonElementalStorm(player, elementType)
    print(player .. " summons an elemental storm of type: " .. elementType)
end

function SystemeGestionTempetesElementaires:ControlStorm(player, stormType)
    print(player .. " controls the elemental storm of type: " .. stormType)
end

return SystemeGestionTempetesElementaires
