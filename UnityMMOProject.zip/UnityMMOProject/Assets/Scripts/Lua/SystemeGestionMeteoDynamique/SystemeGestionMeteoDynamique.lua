SystemeGestionMeteoDynamique = {}

function SystemeGestionMeteoDynamique:SetWeatherCondition(condition)
    print("The weather changes to: " .. condition)
end

function SystemeGestionMeteoDynamique:ApplyWeatherEffects(player, condition)
    print("Applying " .. condition .. " effects to " .. player)
end

return SystemeGestionMeteoDynamique
