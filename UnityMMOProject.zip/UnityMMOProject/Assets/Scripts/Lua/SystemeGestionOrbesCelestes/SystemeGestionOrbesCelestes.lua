SystemeGestionOrbesCelestes = {}

function SystemeGestionOrbesCelestes:DiscoverCelestialOrb(player, orbName)
    print(player .. " discovers a celestial orb: " .. orbName)
end

function SystemeGestionOrbesCelestes:ActivateOrbPower(player, powerType)
    print(player .. " activates the celestial orb power: " .. powerType)
end

return SystemeGestionOrbesCelestes
