SystemeGestionAlchimie = {}

function SystemeGestionAlchimie:CombineIngredients(player, ingredient1, ingredient2)
    print(player .. " combines " .. ingredient1 .. " and " .. ingredient2 .. " to create a potion")
end

function SystemeGestionAlchimie:CreateElixir(player, elixirType)
    print(player .. " creates an elixir of " .. elixirType)
end

return SystemeGestionAlchimie
