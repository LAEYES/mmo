SystemePvP = {}

function SystemePvP:ChallengePlayer(player1, player2)
    print(player1 .. " challenges " .. player2 .. " to a duel!")
end

function SystemePvP:StartDuel(player1, player2)
    print("Duel started between " .. player1 .. " and " .. player2)
end

function SystemePvP:DeclareWinner(winner, loser)
    print(winner .. " has won the duel against " .. loser)
end

return SystemePvP
