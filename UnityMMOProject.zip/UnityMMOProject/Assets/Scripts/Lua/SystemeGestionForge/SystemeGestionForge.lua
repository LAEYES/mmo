SystemeGestionForge = {}

function SystemeGestionForge:CraftItem(player, itemName)
    print(player .. " crafts an item: " .. itemName)
end

function SystemeGestionForge:UpgradeItem(player, itemName)
    print(player .. " upgrades the item: " .. itemName)
end

return SystemeGestionForge
