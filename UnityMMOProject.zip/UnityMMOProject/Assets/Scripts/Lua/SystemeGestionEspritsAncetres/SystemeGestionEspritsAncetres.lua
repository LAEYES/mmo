SystemeGestionEspritsAncetres = {}

function SystemeGestionEspritsAncetres:SummonAncestralSpirit(player, ancestorName)
    print(player .. " summons the ancestral spirit: " .. ancestorName)
end

function SystemeGestionEspritsAncetres:ReceiveAncestralBlessing(player, blessingType)
    print(player .. " receives an ancestral blessing of type: " .. blessingType)
end

return SystemeGestionEspritsAncetres
