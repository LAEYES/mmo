SystemeReussite = {}

function SystemeReussite:UnlockAchievement(player, achievement)
    print(player .. " has unlocked achievement: " .. achievement)
end

return SystemeReussite
