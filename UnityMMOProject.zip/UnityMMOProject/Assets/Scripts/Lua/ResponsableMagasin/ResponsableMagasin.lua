ResponsableMagasin = {}

function ResponsableMagasin:PurchaseItem(player, item, price)
    print(player .. " purchases " .. item .. " for " .. price .. " coins.")
end

function ResponsableMagasin:SellItem(player, item, price)
    print(player .. " sells " .. item .. " for " .. price .. " coins.")
end

return ResponsableMagasin
