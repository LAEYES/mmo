SystemeGestionAlliancesMystiques = {}

function SystemeGestionAlliancesMystiques:FormAlliance(player, entityName)
    print(player .. " forms an alliance with: " .. entityName)
end

function SystemeGestionAlliancesMystiques:ReceiveAllianceBenefit(player, benefitType)
    print(player .. " receives an alliance benefit of type: " .. benefitType)
end

return SystemeGestionAlliancesMystiques
