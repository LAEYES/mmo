SystemeGestionCouronnesDivines = {}

function SystemeGestionCouronnesDivines:FindDivineCrown(player, crownName)
    print(player .. " discovers a divine crown: " .. crownName)
end

function SystemeGestionCouronnesDivines:WearDivineCrown(player, crownName)
    print(player .. " wears the divine crown: " .. crownName .. " and gains a royal aura")
end

return SystemeGestionCouronnesDivines
