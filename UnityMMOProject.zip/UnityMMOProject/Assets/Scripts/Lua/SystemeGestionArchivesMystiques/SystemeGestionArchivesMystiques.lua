SystemeGestionArchivesMystiques = {}

function SystemeGestionArchivesMystiques:ConsultArchive(player, archiveName)
    print(player .. " consults the mystic archive: " .. archiveName)
end

function SystemeGestionArchivesMystiques:LearnAncientSpell(player, spellName)
    print(player .. " learns the ancient spell: " .. spellName)
end

return SystemeGestionArchivesMystiques
