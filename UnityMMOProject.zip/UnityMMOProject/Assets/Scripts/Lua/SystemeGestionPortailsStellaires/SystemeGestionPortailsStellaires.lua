SystemeGestionPortailsStellaires = {}

function SystemeGestionPortailsStellaires:OpenStellarPortal(player, portalName)
    print(player .. " opens a stellar portal to: " .. portalName)
end

function SystemeGestionPortailsStellaires:TravelThroughStellarPortal(player, destination)
    print(player .. " travels to the stellar destination: " .. destination)
end

return SystemeGestionPortailsStellaires
