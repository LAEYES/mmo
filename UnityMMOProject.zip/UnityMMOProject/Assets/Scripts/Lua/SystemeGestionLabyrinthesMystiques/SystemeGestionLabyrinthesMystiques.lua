SystemeGestionLabyrinthesMystiques = {}

function SystemeGestionLabyrinthesMystiques:EnterLabyrinth(player, labyrinthName)
    print(player .. " enters the mystic labyrinth: " .. labyrinthName)
end

function SystemeGestionLabyrinthesMystiques:SolveLabyrinth(player, labyrinthName)
    print(player .. " solves the mystic labyrinth: " .. labyrinthName)
end

return SystemeGestionLabyrinthesMystiques
