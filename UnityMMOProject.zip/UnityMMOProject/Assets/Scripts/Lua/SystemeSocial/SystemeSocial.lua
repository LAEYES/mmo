SystemeSocial = {}

function SystemeSocial:AddFriend(player, friend)
    print(player .. " has added " .. friend .. " as a friend.")
end

function SystemeSocial:SendInvitation(player, invitee)
    print(player .. " sends an invitation to " .. invitee)
end

return SystemeSocial
