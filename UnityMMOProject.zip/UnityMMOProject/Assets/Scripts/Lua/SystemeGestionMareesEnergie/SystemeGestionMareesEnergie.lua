SystemeGestionMareesEnergie = {}

function SystemeGestionMareesEnergie:ChannelEnergyTide(player, tideType)
    print(player .. " channels the energy tide of type: " .. tideType)
end

function SystemeGestionMareesEnergie:ReleaseEnergy(player, tideType)
    print(player .. " releases the energy from the tide: " .. tideType)
end

return SystemeGestionMareesEnergie
