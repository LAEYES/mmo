SystemeGestionFragmentsRealite = {}

function SystemeGestionFragmentsRealite:CollectRealityFragment(player, fragmentType)
    print(player .. " collects a fragment of reality: " .. fragmentType)
end

function SystemeGestionFragmentsRealite:UseFragmentPower(player, fragmentType)
    print(player .. " uses the power of the reality fragment to alter the environment")
end

return SystemeGestionFragmentsRealite
