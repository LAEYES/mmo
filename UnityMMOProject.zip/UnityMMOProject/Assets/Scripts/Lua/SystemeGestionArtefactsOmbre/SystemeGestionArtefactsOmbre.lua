SystemeGestionArtefactsOmbre = {}

function SystemeGestionArtefactsOmbre:DiscoverShadowArtifact(player, artifactName)
    print(player .. " discovers a shadow artifact: " .. artifactName)
end

function SystemeGestionArtefactsOmbre:UseShadowPower(player, powerType)
    print(player .. " uses the shadow artifact's power: " .. powerType)
end

return SystemeGestionArtefactsOmbre
