SystemePersonnalisationLogement = {}

function SystemePersonnalisationLogement:PurchaseItem(player, item)
    print(player .. " purchases a new housing item: " .. item)
end

function SystemePersonnalisationLogement:PlaceItem(player, item, location)
    print(player .. " places " .. item .. " in their home at " .. location)
end

return SystemePersonnalisationLogement
