SystemeGestionPieges = {}

function SystemeGestionPieges:SetTrap(player, trapType, location)
    print(player .. " sets a " .. trapType .. " trap at " .. location)
end

function SystemeGestionPieges:TriggerTrap(player, trapType)
    print("The trap " .. trapType .. " is triggered by " .. player)
end

return SystemeGestionPieges
