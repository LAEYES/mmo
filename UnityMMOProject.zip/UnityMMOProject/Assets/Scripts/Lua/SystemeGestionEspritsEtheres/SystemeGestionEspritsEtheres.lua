SystemeGestionEspritsEtheres = {}

function SystemeGestionEspritsEtheres:SummonEtherealSpirit(player, spiritName)
    print(player .. " summons the ethereal spirit: " .. spiritName)
end

function SystemeGestionEspritsEtheres:GainSpiritWisdom(player, spiritName)
    print(player .. " gains wisdom from the ethereal spirit: " .. spiritName)
end

return SystemeGestionEspritsEtheres
