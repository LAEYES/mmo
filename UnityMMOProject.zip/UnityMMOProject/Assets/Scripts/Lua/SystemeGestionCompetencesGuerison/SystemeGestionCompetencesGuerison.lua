SystemeGestionCompetencesGuerison = {}

function SystemeGestionCompetencesGuerison:Heal(player, target, amount)
    print(player .. " heals " .. target .. " for " .. amount .. " HP")
end

function SystemeGestionCompetencesGuerison:Revive(player, target)
    print(player .. " revives " .. target)
end

return SystemeGestionCompetencesGuerison
