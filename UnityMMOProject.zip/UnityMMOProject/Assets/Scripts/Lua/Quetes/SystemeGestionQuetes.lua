SystemeGestionQuetes = {}

function SystemeGestionQuetes:StartQuest(player, questID)
    print(player .. " starts quest: " .. questID)
end

function SystemeGestionQuetes:CompleteQuest(player, questID)
    print(player .. " completes quest: " .. questID)
end

return SystemeGestionQuetes
