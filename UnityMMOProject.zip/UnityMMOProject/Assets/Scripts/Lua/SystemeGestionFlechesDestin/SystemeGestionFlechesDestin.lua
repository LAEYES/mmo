SystemeGestionFlechesDestin = {}

function SystemeGestionFlechesDestin:CraftDestinyArrow(player, arrowType)
    print(player .. " crafts a destiny arrow of type: " .. arrowType)
end

function SystemeGestionFlechesDestin:UseArrow(player, target)
    print(player .. " uses a destiny arrow on " .. target)
end

return SystemeGestionFlechesDestin
