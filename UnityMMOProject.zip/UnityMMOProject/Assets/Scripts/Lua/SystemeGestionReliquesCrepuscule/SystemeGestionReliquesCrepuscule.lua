SystemeGestionReliquesCrepuscule = {}

function SystemeGestionReliquesCrepuscule:DiscoverTwilightRelic(player, relicName)
    print(player .. " discovers a twilight relic: " .. relicName)
end

function SystemeGestionReliquesCrepuscule:ActivateTwilightRelic(player, relicName)
    print(player .. " activates the twilight relic: " .. relicName)
end

return SystemeGestionReliquesCrepuscule
