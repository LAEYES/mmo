SystemeGestionDonjonsAleatoires = {}

function SystemeGestionDonjonsAleatoires:GenerateDungeon(player, difficulty)
    print("Generating a random dungeon for " .. player .. " with difficulty: " .. difficulty)
end

function SystemeGestionDonjonsAleatoires:StartDungeon(player)
    print(player .. " is entering a randomly generated dungeon")
end

function SystemeGestionDonjonsAleatoires:EndDungeon(player)
    print(player .. " has completed the random dungeon")
end

return SystemeGestionDonjonsAleatoires
