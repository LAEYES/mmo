SystemeGestionCristauxInvincibilite = {}

function SystemeGestionCristauxInvincibilite:FindInvincibilityCrystal(player, crystalType)
    print(player .. " finds an invincibility crystal of type: " .. crystalType)
end

function SystemeGestionCristauxInvincibilite:UseInvincibility(player)
    print(player .. " becomes invincible for a limited time!")
end

return SystemeGestionCristauxInvincibilite
