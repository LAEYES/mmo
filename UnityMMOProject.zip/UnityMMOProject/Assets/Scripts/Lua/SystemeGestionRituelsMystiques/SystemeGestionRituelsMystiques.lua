SystemeGestionRituelsMystiques = {}

function SystemeGestionRituelsMystiques:PerformRitual(player, ritualName)
    print(player .. " performs the mystic ritual: " .. ritualName)
end

function SystemeGestionRituelsMystiques:ActivateRitualPower(player, powerType)
    print(player .. " activates the power of the ritual: " .. powerType)
end

return SystemeGestionRituelsMystiques
