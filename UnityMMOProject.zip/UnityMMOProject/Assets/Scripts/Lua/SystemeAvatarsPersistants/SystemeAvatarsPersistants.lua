SystemeAvatarsPersistants = {}

function SystemeAvatarsPersistants:KeepAvatarOnline(player)
    print("Avatar for player " .. player .. " remains online")
end

function SystemeAvatarsPersistants:RemoveAvatar(player)
    print("Avatar for player " .. player .. " is removed from the world")
end

return SystemeAvatarsPersistants
