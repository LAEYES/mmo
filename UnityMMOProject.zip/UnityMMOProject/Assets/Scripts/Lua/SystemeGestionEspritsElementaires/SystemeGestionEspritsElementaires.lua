SystemeGestionEspritsElementaires = {}

function SystemeGestionEspritsElementaires:SummonElementalSpirit(player, elementType)
    print(player .. " summons an elemental spirit of type: " .. elementType)
end

function SystemeGestionEspritsElementaires:UseSpiritPower(player, powerType)
    print(player .. " uses the elemental spirit's power of type: " .. powerType)
end

return SystemeGestionEspritsElementaires
