SystemeGestionGemmesPuissance = {}

function SystemeGestionGemmesPuissance:FindPowerGem(player, gemType)
    print(player .. " finds a power gem of type: " .. gemType)
end

function SystemeGestionGemmesPuissance:UseGemPower(player, powerType)
    print(player .. " uses the power of the gem: " .. powerType)
end

return SystemeGestionGemmesPuissance
