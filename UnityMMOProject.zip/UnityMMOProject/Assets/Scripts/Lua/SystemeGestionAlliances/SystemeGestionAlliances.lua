SystemeGestionAlliances = {}

function SystemeGestionAlliances:FormAlliance(player, allianceName)
    print(player .. " forms a new alliance: " .. allianceName)
end

function SystemeGestionAlliances:JoinAlliance(player, allianceName)
    print(player .. " joins the alliance: " .. allianceName)
end

function SystemeGestionAlliances:ShareResources(player, allianceName, resource, amount)
    print(player .. " shares " .. amount .. " of " .. resource .. " with alliance " .. allianceName)
end

return SystemeGestionAlliances
