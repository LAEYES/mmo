SystemeNPC = {}

function SystemeNPC:TalkTo(npc, player)
    print(player .. " talks to " .. npc)
end

function SystemeNPC:GiveQuest(npc, player, quest)
    print(npc .. " gives quest '" .. quest .. "' to " .. player)
end

return SystemeNPC
