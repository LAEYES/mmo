SystemeGestionBoucliersEnergie = {}

function SystemeGestionBoucliersEnergie:CreateEnergyShield(player, shieldType)
    print(player .. " creates an energy shield of type: " .. shieldType)
end

function SystemeGestionBoucliersEnergie:StrengthenShield(player, shieldType)
    print(player .. " strengthens the energy shield of type: " .. shieldType)
end

return SystemeGestionBoucliersEnergie
