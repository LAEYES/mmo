SystemeGestionCompagnonsDomestiques = {}

function SystemeGestionCompagnonsDomestiques:AdoptPet(player, petType)
    print(player .. " adopts a pet: " .. petType)
end

function SystemeGestionCompagnonsDomestiques:InteractWithPet(player, petType)
    print(player .. " interacts with their pet: " .. petType)
end

function SystemeGestionCompagnonsDomestiques:ReleasePet(player, petType)
    print(player .. " releases their pet: " .. petType)
end

return SystemeGestionCompagnonsDomestiques
