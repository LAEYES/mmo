SystemeGestionPortailsInterdimensionnels = {}

function SystemeGestionPortailsInterdimensionnels:OpenPortal(player, dimension)
    print(player .. " opens a portal to the dimension: " .. dimension)
end

function SystemeGestionPortailsInterdimensionnels:ClosePortal(player, dimension)
    print(player .. " closes the portal to the dimension: " .. dimension)
end

return SystemeGestionPortailsInterdimensionnels
