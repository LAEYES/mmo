SystemeGestionPactesDraconiques = {}

function SystemeGestionPactesDraconiques:FormDraconicPact(player, dragonName)
    print(player .. " forms a draconic pact with " .. dragonName)
end

function SystemeGestionPactesDraconiques:InvokeDragonPower(player, powerName)
    print(player .. " invokes the dragon power: " .. powerName)
end

return SystemeGestionPactesDraconiques
