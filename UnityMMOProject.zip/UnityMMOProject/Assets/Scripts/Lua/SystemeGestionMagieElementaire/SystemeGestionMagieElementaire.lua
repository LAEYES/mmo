SystemeGestionMagieElementaire = {}

function SystemeGestionMagieElementaire:CastElementalSpell(player, element, spellName)
    print(player .. " casts a " .. element .. " spell: " .. spellName)
end

function SystemeGestionMagieElementaire:CombineElements(player, element1, element2)
    print(player .. " combines " .. element1 .. " and " .. element2 .. " to create a powerful effect")
end

return SystemeGestionMagieElementaire
