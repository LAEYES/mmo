SystemeGestionArtefactsCosmiques = {}

function SystemeGestionArtefactsCosmiques:FindCosmicArtifact(player, artifactName)
    print(player .. " finds a cosmic artifact: " .. artifactName)
end

function SystemeGestionArtefactsCosmiques:UseCosmicPower(player, artifactName)
    print(player .. " uses the cosmic power of the artifact: " .. artifactName)
end

return SystemeGestionArtefactsCosmiques
