SystemeGestionVeilleursEtoiles = {}

function SystemeGestionVeilleursEtoiles:SummonStarWatcher(player, watcherName)
    print(player .. " summons the star watcher: " .. watcherName)
end

function SystemeGestionVeilleursEtoiles:ReceiveCelestialBlessing(player, blessingType)
    print(player .. " receives a celestial blessing of type: " .. blessingType)
end

return SystemeGestionVeilleursEtoiles
