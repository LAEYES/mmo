SystemeGestionSentinellesSpirituelles = {}

function SystemeGestionSentinellesSpirituelles:SummonSpiritualSentinel(player, sentinelName)
    print(player .. " summons the spiritual sentinel: " .. sentinelName)
end

function SystemeGestionSentinellesSpirituelles:MonitorArea(player, areaName)
    print(player .. " sets the spiritual sentinel to monitor the area: " .. areaName)
end

return SystemeGestionSentinellesSpirituelles
