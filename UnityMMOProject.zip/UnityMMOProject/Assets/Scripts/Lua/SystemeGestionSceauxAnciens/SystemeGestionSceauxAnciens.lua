SystemeGestionSceauxAnciens = {}

function SystemeGestionSceauxAnciens:BreakAncientSeal(player, sealName)
    print(player .. " breaks the ancient seal: " .. sealName)
end

function SystemeGestionSceauxAnciens:ReleaseSealPower(player, powerType)
    print(player .. " releases the power of the seal: " .. powerType)
end

return SystemeGestionSceauxAnciens
