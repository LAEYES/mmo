-- Audio management for handling sound effects and background music
Audio = {}

function Audio:PlaySoundEffect(soundName)
    print('Playing sound effect: ' .. soundName)
    -- Placeholder code for playing sound
end

function Audio:PlayBackgroundMusic(trackName)
    print('Playing background music: ' .. trackName)
    -- Placeholder code for playing music
end

function Audio:StopBackgroundMusic()
    print('Stopping background music.')
end
