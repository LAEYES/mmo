SystemeGestionChimeresLegendaires = {}

function SystemeGestionChimeresLegendaires:SummonChimera(player, chimeraName)
    print(player .. " summons the legendary chimera: " .. chimeraName)
end

function SystemeGestionChimeresLegendaires:UseChimeraPower(player, powerType)
    print(player .. " uses the power of the chimera: " .. powerType)
end

return SystemeGestionChimeresLegendaires
