SystemeGestionMercenaires = {}

function SystemeGestionMercenaires:HireMercenary(player, mercenaryType)
    print(player .. " hires a mercenary of type: " .. mercenaryType)
end

function SystemeGestionMercenaires:DismissMercenary(player, mercenaryType)
    print(player .. " dismisses the mercenary of type: " .. mercenaryType)
end

return SystemeGestionMercenaires
