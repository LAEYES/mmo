SystemeGestionAmulettesAnciennes = {}

function SystemeGestionAmulettesAnciennes:DiscoverAncientAmulet(player, amuletName)
    print(player .. " discovers an ancient amulet: " .. amuletName)
end

function SystemeGestionAmulettesAnciennes:UseAmuletPower(player, powerType)
    print(player .. " uses the power of the ancient amulet: " .. powerType)
end

return SystemeGestionAmulettesAnciennes
