-- Character status system
CharacterStatus = {
    health = 100,
    energy = 100,
    statusEffects = {}
}

function CharacterStatus:TakeDamage(amount)
    self.health = self.health - amount
    if self.health <= 0 then
        self:Die()
    else
        print('Health now: ' .. self.health)
    end
end

function CharacterStatus:RestoreHealth(amount)
    self.health = self.health + amount
    print('Health restored by ' .. amount .. '. Health now: ' .. self.health)
end

function CharacterStatus:ApplyStatusEffect(effect)
    table.insert(self.statusEffects, effect)
    print('Status effect ' .. effect .. ' applied.')
end

function CharacterStatus:Die()
    print('Character has died.')
end
