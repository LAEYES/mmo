SystemeGestionMeteo = {}

function SystemeGestionMeteo:ChangeWeather(condition)
    print("Weather has changed to: " .. condition)
end

function SystemeGestionMeteo:ForecastWeather()
    local forecast = "Sunny, with a chance of rain"
    print("Weather forecast: " .. forecast)
    return forecast
end

return SystemeGestionMeteo
