SystemeGestionLarmesDragon = {}

function SystemeGestionLarmesDragon:CollectDragonTear(player, tearType)
    print(player .. " collects a dragon tear of type: " .. tearType)
end

function SystemeGestionLarmesDragon:UseTearPower(player, powerType)
    print(player .. " uses the power of the dragon tear: " .. powerType)
end

return SystemeGestionLarmesDragon
