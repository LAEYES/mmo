SystemeGestionReliquesTemporaires = {}

function SystemeGestionReliquesTemporaires:FindTemporalRelic(player, relicName)
    print(player .. " discovers a temporal relic: " .. relicName)
end

function SystemeGestionReliquesTemporaires:UseRelicPower(player, timeEffect)
    print(player .. " uses the relic to " .. timeEffect .. " time")
end

return SystemeGestionReliquesTemporaires
