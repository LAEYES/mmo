SystemeGestionRessourcesMineralesAvancees = {}

function SystemeGestionRessourcesMineralesAvancees:MineMineral(player, mineralType)
    print(player .. " mines " .. mineralType)
end

function SystemeGestionRessourcesMineralesAvancees:RefineMineral(player, mineralType)
    print(player .. " refines the mineral: " .. mineralType)
end

return SystemeGestionRessourcesMineralesAvancees
