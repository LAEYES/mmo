SystemeGestionObjetsCollection = {}

function SystemeGestionObjetsCollection:AddCollectible(player, collectible)
    print(player .. " has obtained a collectible: " .. collectible)
end

function SystemeGestionObjetsCollection:CompleteCollection(player, collectionName)
    print(player .. " has completed the collection: " .. collectionName)
end

return SystemeGestionObjetsCollection
