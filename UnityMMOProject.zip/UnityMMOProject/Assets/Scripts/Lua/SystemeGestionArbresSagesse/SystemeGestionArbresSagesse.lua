SystemeGestionArbresSagesse = {}

function SystemeGestionArbresSagesse:MeditateUnderTree(player, treeName)
    print(player .. " meditates under the tree of wisdom: " .. treeName)
end

function SystemeGestionArbresSagesse:GainKnowledge(player)
    print(player .. " gains ancient knowledge from the tree of wisdom")
end

return SystemeGestionArbresSagesse
