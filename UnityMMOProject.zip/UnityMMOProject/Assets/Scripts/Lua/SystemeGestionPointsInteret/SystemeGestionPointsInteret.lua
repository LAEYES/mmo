SystemeGestionPointsInteret = {}

function SystemeGestionPointsInteret:DiscoverPointOfInterest(player, location)
    print(player .. " has discovered a point of interest at " .. location)
end

function SystemeGestionPointsInteret:ReceiveReward(player, location)
    print(player .. " receives a reward for exploring " .. location)
end

return SystemeGestionPointsInteret
