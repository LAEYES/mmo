SystemeGestionLignesLey = {}

function SystemeGestionLignesLey:AccessLeyLine(player, leyLineName)
    print(player .. " accesses the ley line: " .. leyLineName)
end

function SystemeGestionLignesLey:AbsorbLeyEnergy(player, leyLineName)
    print(player .. " absorbs energy from the ley line: " .. leyLineName)
end

return SystemeGestionLignesLey
