SystemeGestionEnigmesAncestrales = {}

function SystemeGestionEnigmesAncestrales:StartAncientPuzzle(player, puzzleName)
    print(player .. " starts the ancient puzzle: " .. puzzleName)
end

function SystemeGestionEnigmesAncestrales:CompletePuzzle(player, puzzleName)
    print(player .. " completes the puzzle: " .. puzzleName)
end

return SystemeGestionEnigmesAncestrales
