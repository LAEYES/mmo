SystemeMontage = {}

function SystemeMontage:AcquireMount(player, mountName)
    print(player .. " acquires the mount: " .. mountName)
end

function SystemeMontage:RideMount(player, mountName)
    print(player .. " is riding " .. mountName)
end

function SystemeMontage:Dismount(player)
    print(player .. " dismounts.")
end

return SystemeMontage
