SystemeGestionTempetesOmbre = {}

function SystemeGestionTempetesOmbre:SummonShadowStorm(player, stormType)
    print(player .. " summons a shadow storm of type: " .. stormType)
end

function SystemeGestionTempetesOmbre:DissipateShadowStorm(player, stormType)
    print(player .. " dissipates the shadow storm of type: " .. stormType)
end

return SystemeGestionTempetesOmbre
