SystemeGestionAvatarsCelestes = {}

function SystemeGestionAvatarsCelestes:SummonCelestialAvatar(player, avatarName)
    print(player .. " summons the celestial avatar: " .. avatarName)
end

function SystemeGestionAvatarsCelestes:ReceiveAvatarPower(player, powerType)
    print(player .. " receives a celestial power of type: " .. powerType)
end

return SystemeGestionAvatarsCelestes
