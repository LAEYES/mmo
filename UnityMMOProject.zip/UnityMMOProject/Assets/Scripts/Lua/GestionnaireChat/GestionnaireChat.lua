GestionnaireChat = {}

function GestionnaireChat:SendMessage(player, message)
    print(player .. " says: " .. message)
end

function GestionnaireChat:PrivateMessage(sender, receiver, message)
    print(sender .. " whispers to " .. receiver .. ": " .. message)
end

return GestionnaireChat
