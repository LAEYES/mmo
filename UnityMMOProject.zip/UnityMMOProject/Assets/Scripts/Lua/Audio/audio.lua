-- Audio management for handling sound effects and background music
Audio = {}

function Audio:PlaySoundEffect(soundName)
    print('Playing sound effect: ' .. soundName)
end

function Audio:PlayBackgroundMusic(trackName)
    print('Playing background music: ' .. trackName)
end

function Audio:StopBackgroundMusic()
    print('Stopping background music.')
end
