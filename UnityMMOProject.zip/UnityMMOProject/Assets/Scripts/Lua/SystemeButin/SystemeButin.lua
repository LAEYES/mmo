SystemeButin = {}

function SystemeButin:GenerateLoot(enemy)
    print("Generating loot for defeating " .. enemy)
    local loot = {"Gold", "Sword", "Potion"}
    return loot
end

function SystemeButin:CollectLoot(player, loot)
    print(player .. " collects loot: " .. table.concat(loot, ", "))
end

return SystemeButin
