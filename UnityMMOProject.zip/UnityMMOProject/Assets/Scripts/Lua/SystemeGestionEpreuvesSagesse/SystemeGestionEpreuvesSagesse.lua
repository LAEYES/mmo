SystemeGestionEpreuvesSagesse = {}

function SystemeGestionEpreuvesSagesse:StartWisdomTrial(player, trialName)
    print(player .. " starts the wisdom trial: " .. trialName)
end

function SystemeGestionEpreuvesSagesse:CompleteWisdomTrial(player, trialName)
    print(player .. " completes the wisdom trial: " .. trialName)
end

return SystemeGestionEpreuvesSagesse
