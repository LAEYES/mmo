SystemeGestionAvatarsPersonnalises = {}

function SystemeGestionAvatarsPersonnalises:ChangeAppearance(player, appearance)
    print(player .. " has changed their appearance to: " .. appearance)
end

function SystemeGestionAvatarsPersonnalises:EquipItem(player, item)
    print(player .. " equips " .. item)
end

return SystemeGestionAvatarsPersonnalises
