SystemeGestionAgriculture = {}

function SystemeGestionAgriculture:PlantCrop(player, cropType)
    print(player .. " plants a crop: " .. cropType)
end

function SystemeGestionAgriculture:HarvestCrop(player, cropType)
    print(player .. " harvests crop: " .. cropType)
end

return SystemeGestionAgriculture
