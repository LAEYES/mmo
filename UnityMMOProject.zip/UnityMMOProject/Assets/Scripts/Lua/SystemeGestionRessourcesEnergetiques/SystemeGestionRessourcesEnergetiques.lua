SystemeGestionRessourcesEnergetiques = {}

function SystemeGestionRessourcesEnergetiques:CollectEnergyResource(player, resourceType, amount)
    print(player .. " collects " .. amount .. " units of " .. resourceType)
end

function SystemeGestionRessourcesEnergetiques:UseEnergyResource(player, resourceType, amount)
    print(player .. " uses " .. amount .. " units of " .. resourceType)
end

return SystemeGestionRessourcesEnergetiques
