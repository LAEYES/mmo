SystemeGestionForetsEnchantees = {}

function SystemeGestionForetsEnchantees:EnterEnchantedForest(player, forestName)
    print(player .. " enters the enchanted forest: " .. forestName)
end

function SystemeGestionForetsEnchantees:ReceiveForestBlessing(player, blessingType)
    print(player .. " receives a forest blessing of type: " .. blessingType)
end

return SystemeGestionForetsEnchantees
