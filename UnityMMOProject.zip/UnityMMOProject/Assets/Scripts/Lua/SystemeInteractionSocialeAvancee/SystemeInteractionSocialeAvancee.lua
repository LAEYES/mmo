SystemeInteractionSocialeAvancee = {}

function SystemeInteractionSocialeAvancee:SendFriendRequest(player, friend)
    print(player .. " sends a friend request to " .. friend)
end

function SystemeInteractionSocialeAvancee:InitiateTrade(player1, player2, item)
    print(player1 .. " initiates trade with " .. player2 .. " for " .. item)
end

function SystemeInteractionSocialeAvancee:Duel(player1, player2)
    print(player1 .. " challenges " .. player2 .. " to a duel!")
end

return SystemeInteractionSocialeAvancee
