-- Skills system
Skill = {
    name = '',
    power = 0,
    cooldown = 0,
    isAvailable = true
}

function Skill:UseSkill(target)
    if self.isAvailable then
        print('Using skill ' .. self.name .. ' on ' .. target.name)
        target:TakeDamage(self.power)
        self:StartCooldown()
    else
        print('Skill ' .. self.name .. ' is on cooldown.')
    end
end

function Skill:StartCooldown()
    self.isAvailable = false
    print(self.name .. ' is now on cooldown for ' .. self.cooldown .. ' seconds.')
end
