SystemeGestionEvenementsGuilde = {}

function SystemeGestionEvenementsGuilde:StartGuildEvent(guild, eventName)
    print("Guild " .. guild .. " is starting the event: " .. eventName)
end

function SystemeGestionEvenementsGuilde:EndGuildEvent(guild, eventName)
    print("Guild " .. guild .. " has completed the event: " .. eventName)
end

return SystemeGestionEvenementsGuilde
