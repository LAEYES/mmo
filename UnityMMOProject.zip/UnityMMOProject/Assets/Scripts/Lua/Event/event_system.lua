-- Event system for dynamic game events
EventSystem = {
    activeEvents = {}
}

function EventSystem:StartEvent(eventName, description)
    local event = {
        name = eventName,
        description = description,
        isActive = true
    }
    table.insert(self.activeEvents, event)
    print('Event started: ' .. eventName .. ' - ' .. description)
end

function EventSystem:EndEvent(eventName)
    for i, event in ipairs(self.activeEvents) do
        if event.name == eventName then
            event.isActive = false
            print('Event ended: ' .. eventName)
            table.remove(self.activeEvents, i)
            break
        end
    end
end

function EventSystem:ListActiveEvents()
    print('Active events:')
    for _, event in ipairs(self.activeEvents) do
        print('- ' .. event.name .. ': ' .. event.description)
    end
end
