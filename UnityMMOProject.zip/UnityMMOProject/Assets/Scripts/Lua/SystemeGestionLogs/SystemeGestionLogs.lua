SystemeGestionLogs = {}

function SystemeGestionLogs:LogAction(player, action)
    print("[LOG] " .. player .. " performed action: " .. action)
end

function SystemeGestionLogs:LogEvent(event)
    print("[EVENT LOG] " .. event)
end

return SystemeGestionLogs
