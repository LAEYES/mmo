SystemeGestionSanctuairesNature = {}

function SystemeGestionSanctuairesNature:FindNatureSanctuary(player, sanctuaryName)
    print(player .. " finds a nature sanctuary: " .. sanctuaryName)
end

function SystemeGestionSanctuairesNature:ReceiveNatureBlessing(player, blessingType)
    print(player .. " receives a nature blessing from the sanctuary: " .. blessingType)
end

return SystemeGestionSanctuairesNature
