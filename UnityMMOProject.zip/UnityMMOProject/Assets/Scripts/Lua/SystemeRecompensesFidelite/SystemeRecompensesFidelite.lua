SystemeRecompensesFidelite = {}

function SystemeRecompensesFidelite:RewardForLoginStreak(player, days)
    print(player .. " has logged in for " .. days .. " consecutive days and receives a loyalty reward.")
end

function SystemeRecompensesFidelite:RewardForPlaytime(player, hours)
    print(player .. " has played for " .. hours .. " hours and receives a loyalty reward.")
end

return SystemeRecompensesFidelite
