SystemeGestionAnneauxPouvoir = {}

function SystemeGestionAnneauxPouvoir:DiscoverPowerRing(player, ringName)
    print(player .. " discovers a power ring: " .. ringName)
end

function SystemeGestionAnneauxPouvoir:EquipRing(player, ringName)
    print(player .. " equips the power ring: " .. ringName)
end

return SystemeGestionAnneauxPouvoir
