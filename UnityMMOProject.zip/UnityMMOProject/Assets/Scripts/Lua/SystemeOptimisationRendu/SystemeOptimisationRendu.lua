SystemeOptimisationRendu = {}

function SystemeOptimisationRendu:AdjustGraphicsQuality(player, quality)
    print("Setting graphics quality for " .. player .. " to " .. quality)
end

function SystemeOptimisationRendu:OptimizeFrameRate(player)
    print("Optimizing frame rate for " .. player)
end

return SystemeOptimisationRendu
