SystemeGestionFamiliers = {}

function SystemeGestionFamiliers:CapturePet(player, petName)
    print(player .. " has captured a pet: " .. petName)
end

function SystemeGestionFamiliers:TrainPet(player, petName, skill)
    print(player .. " is training " .. petName .. " in " .. skill)
end

function SystemeGestionFamiliers:ReleasePet(player, petName)
    print(player .. " has released their pet: " .. petName)
end

return SystemeGestionFamiliers
