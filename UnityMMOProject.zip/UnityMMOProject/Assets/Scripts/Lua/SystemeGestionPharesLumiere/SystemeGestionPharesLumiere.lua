SystemeGestionPharesLumiere = {}

function SystemeGestionPharesLumiere:BuildLightBeacon(player, beaconName)
    print(player .. " builds a light beacon: " .. beaconName)
end

function SystemeGestionPharesLumiere:IlluminateArea(player, beaconName)
    print(player .. " uses the beacon to illuminate the area around: " .. beaconName)
end

return SystemeGestionPharesLumiere
