SystemeGestionEnvironnement = {}

function SystemeGestionEnvironnement:ChangeWeather(weatherType)
    print("Changing weather to: " .. weatherType)
end

function SystemeGestionEnvironnement:SetTimeOfDay(timeOfDay)
    print("Setting time of day to: " .. timeOfDay)
end

return SystemeGestionEnvironnement
