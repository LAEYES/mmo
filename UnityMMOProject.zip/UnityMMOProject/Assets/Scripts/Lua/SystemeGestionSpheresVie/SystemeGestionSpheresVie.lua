SystemeGestionSpheresVie = {}

function SystemeGestionSpheresVie:FindLifeSphere(player, sphereName)
    print(player .. " finds a life sphere: " .. sphereName)
end

function SystemeGestionSpheresVie:UseLifeSphere(player, sphereName)
    print(player .. " uses the life sphere: " .. sphereName .. " to heal")
end

return SystemeGestionSpheresVie
