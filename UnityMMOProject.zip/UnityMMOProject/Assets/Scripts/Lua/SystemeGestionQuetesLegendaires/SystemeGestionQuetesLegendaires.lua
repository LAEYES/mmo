SystemeGestionQuetesLegendaires = {}

function SystemeGestionQuetesLegendaires:StartLegendaryQuest(player, questName)
    print(player .. " embarks on the legendary quest: " .. questName)
end

function SystemeGestionQuetesLegendaires:CompleteLegendaryQuest(player, questName)
    print(player .. " completes the legendary quest: " .. questName)
end

return SystemeGestionQuetesLegendaires
