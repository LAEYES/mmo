GestionnaireBoss = {}

function GestionnaireBoss:SpawnBoss(bossName, location)
    print("Boss " .. bossName .. " has spawned at " .. location)
end

function GestionnaireBoss:DefeatBoss(player, bossName)
    print(player .. " defeats the boss: " .. bossName)
end

function GestionnaireBoss:BossAttack(bossName, skill, target)
    print("Boss " .. bossName .. " uses " .. skill .. " on " .. target)
end

return GestionnaireBoss
