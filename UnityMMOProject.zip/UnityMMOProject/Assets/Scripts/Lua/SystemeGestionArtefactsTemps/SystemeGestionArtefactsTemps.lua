SystemeGestionArtefactsTemps = {}

function SystemeGestionArtefactsTemps:DiscoverTimeArtifact(player, artifactName)
    print(player .. " discovers a time artifact: " .. artifactName)
end

function SystemeGestionArtefactsTemps:UseTimePower(player, powerType)
    print(player .. " uses the time power: " .. powerType)
end

return SystemeGestionArtefactsTemps
