SystemeGuerreTerritoire = {}

function SystemeGuerreTerritoire:DeclareWar(guild1, guild2)
    print("Guild " .. guild1 .. " has declared war on " .. guild2)
end

function SystemeGuerreTerritoire:CaptureTerritory(guild, territory)
    print("Guild " .. guild .. " has captured the territory: " .. territory)
end

return SystemeGuerreTerritoire
