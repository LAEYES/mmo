SystemeGestionSentinellesAnciennes = {}

function SystemeGestionSentinellesAnciennes:SummonAncientSentinel(player, sentinelName)
    print(player .. " summons the ancient sentinel: " .. sentinelName)
end

function SystemeGestionSentinellesAnciennes:DismissSentinel(player, sentinelName)
    print(player .. " dismisses the ancient sentinel: " .. sentinelName)
end

return SystemeGestionSentinellesAnciennes
