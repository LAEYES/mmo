SystemeQuetesAvancees = {}

function SystemeQuetesAvancees:StartQuest(player, questName)
    print(player .. " starts the advanced quest: " .. questName)
end

function SystemeQuetesAvancees:CompleteQuest(player, questName)
    print(player .. " completes the quest: " .. questName)
end

function SystemeQuetesAvancees:TrackProgress(player, questName, progress)
    print(player .. " progresses in " .. questName .. ": " .. progress .. "% complete")
end

return SystemeQuetesAvancees
