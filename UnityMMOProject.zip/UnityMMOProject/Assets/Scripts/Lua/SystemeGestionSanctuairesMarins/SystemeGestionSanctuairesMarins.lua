SystemeGestionSanctuairesMarins = {}

function SystemeGestionSanctuairesMarins:EnterMarineSanctuary(player, sanctuaryName)
    print(player .. " enters the marine sanctuary: " .. sanctuaryName)
end

function SystemeGestionSanctuairesMarins:ReceiveMarineBlessing(player, blessingType)
    print(player .. " receives a marine blessing of type: " .. blessingType)
end

return SystemeGestionSanctuairesMarins
