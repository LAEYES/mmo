using UnityEngine;
using MoonSharp.Interpreter;

public class QuestSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Quetes/SystemeGestionQuetes.lua");
    }

    public void StartQuest(string player, int questID)
    {
        DynValue function = luaScript.Globals.Get("SystemeGestionQuetes").Table.Get("StartQuest");
        luaScript.Call(function, player, questID);
    }

    public void CompleteQuest(string player, int questID)
    {
        DynValue function = luaScript.Globals.Get("SystemeGestionQuetes").Table.Get("CompleteQuest");
        luaScript.Call(function, player, questID);
    }
}
