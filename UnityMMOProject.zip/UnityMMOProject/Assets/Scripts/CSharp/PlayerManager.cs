using Mirror;

public class PlayerManager : NetworkBehaviour
{
    [SyncVar]
    public string playerName;

    public override void OnStartLocalPlayer()
    {
        // Actions pour le joueur local
    }

    [Command]
    public void CmdGainExperience(int amount)
    {
        // Logique de gestion de l exp�rience
    }

    [TargetRpc]
    public void TargetDisplayMessage(NetworkConnection target, string message)
    {
        // Affiche un message au joueur cible
        Debug.Log(message);
    }
}
