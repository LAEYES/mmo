using UnityEngine;
using MoonSharp.Interpreter;

public class EconomySystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Economique/SystemeEconomie.lua");
    }

    public void BuyItem(string player, int itemID, int price)
    {
        DynValue function = luaScript.Globals.Get("SystemeEconomie").Table.Get("BuyItem");
        luaScript.Call(function, player, itemID, price);
    }

    public void SellItem(string player, int itemID, int price)
    {
        DynValue function = luaScript.Globals.Get("SystemeEconomie").Table.Get("SellItem");
        luaScript.Call(function, player, itemID, price);
    }
}
