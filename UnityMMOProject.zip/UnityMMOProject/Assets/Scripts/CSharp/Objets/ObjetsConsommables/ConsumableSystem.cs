using UnityEngine;
using MoonSharp.Interpreter;

public class ConsumableSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Objets/ObjetsConsommables/Consommable.lua");
    }

    public void CreateConsumable(string name, string effect)
    {
        DynValue function = luaScript.Globals.Get("Consommable").Table.Get("Create");
        luaScript.Call(function, name, effect);
    }

    public void UseConsumable(string player)
    {
        DynValue function = luaScript.Globals.Get("Consommable").Table.Get("Use");
        luaScript.Call(function, player);
    }
}
