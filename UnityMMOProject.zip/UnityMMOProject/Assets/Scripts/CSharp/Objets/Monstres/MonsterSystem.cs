using UnityEngine;
using MoonSharp.Interpreter;

public class MonsterSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Objets/Monstres/Monstre.lua");
    }

    public void CreateMonster(string name, int level, int health)
    {
        DynValue function = luaScript.Globals.Get("Monstre").Table.Get("Create");
        luaScript.Call(function, name, level, health);
    }

    public void MonsterAttack(string player, int damage)
    {
        DynValue function = luaScript.Globals.Get("Monstre").Table.Get("Attack");
        luaScript.Call(function, player, damage);
    }
}
