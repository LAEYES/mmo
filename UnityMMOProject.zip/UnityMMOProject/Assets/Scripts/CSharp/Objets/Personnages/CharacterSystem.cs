using UnityEngine;
using MoonSharp.Interpreter;

public class CharacterSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Objets/Personnages/Personnage.lua");
    }

    public void CreateCharacter(string name, string classType, int level)
    {
        DynValue function = luaScript.Globals.Get("Personnage").Table.Get("Create");
        luaScript.Call(function, name, classType, level);
    }

    public void LevelUpCharacter()
    {
        DynValue function = luaScript.Globals.Get("Personnage").Table.Get("LevelUp");
        luaScript.Call(function);
    }
}
