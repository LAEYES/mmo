using UnityEngine;
using MoonSharp.Interpreter;

public class EquipmentSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Objets/Equipements/Equipement.lua");
    }

    public void CreateEquipment(string name, string type, string rarity)
    {
        DynValue function = luaScript.Globals.Get("Equipement").Table.Get("Create");
        luaScript.Call(function, name, type, rarity);
    }

    public void EquipItem(string player)
    {
        DynValue function = luaScript.Globals.Get("Equipement").Table.Get("Equip");
        luaScript.Call(function, player);
    }
}
