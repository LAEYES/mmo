using UnityEngine;
using MoonSharp.Interpreter;

public class EnvironmentObjectSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Objets/Environnement/ObjetEnvironnement.lua");
    }

    public void CreateEnvironmentObject(string name, string interactionType)
    {
        DynValue function = luaScript.Globals.Get("ObjetEnvironnement").Table.Get("Create");
        luaScript.Call(function, name, interactionType);
    }

    public void InteractWithObject(string player)
    {
        DynValue function = luaScript.Globals.Get("ObjetEnvironnement").Table.Get("Interact");
        luaScript.Call(function, player);
    }
}
