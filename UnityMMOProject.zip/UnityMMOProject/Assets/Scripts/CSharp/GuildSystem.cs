using UnityEngine;
using MoonSharp.Interpreter;

public class GuildSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/Guilde/SystemeGestionGuilde.lua");
    }

    public void CreateGuild(string player, string guildName)
    {
        DynValue function = luaScript.Globals.Get("SystemeGestionGuilde").Table.Get("CreateGuild");
        luaScript.Call(function, player, guildName);
    }

    public void JoinGuild(string player, string guildName)
    {
        DynValue function = luaScript.Globals.Get("SystemeGestionGuilde").Table.Get("JoinGuild");
        luaScript.Call(function, player, guildName);
    }
}
