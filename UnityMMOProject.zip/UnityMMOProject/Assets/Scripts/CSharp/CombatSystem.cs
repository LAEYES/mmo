using UnityEngine;
using MoonSharp.Interpreter;

public class CombatSystem : MonoBehaviour
{
    private Script luaScript;

    void Start()
    {
        luaScript = new Script();
        luaScript.DoFile("Assets/Scripts/Lua/SystemeCombat.lua");
    }

    public void StartCombat(string player, string target)
    {
        DynValue function = luaScript.Globals.Get("SystemeCombat").Table.Get("StartCombat");
        luaScript.Call(function, player, target);
    }

    public void ApplyDamage(string player, string target, int damage)
    {
        DynValue function = luaScript.Globals.Get("SystemeCombat").Table.Get("ApplyDamage");
        luaScript.Call(function, player, target, damage);
    }

    public void UseSkill(string player, string skill, string target)
    {
        DynValue function = luaScript.Globals.Get("SystemeCombat").Table.Get("UseSkill");
        luaScript.Call(function, player, skill, target);
    }
}
