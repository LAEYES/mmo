using UnityEngine;
using System.Collections;
using NLua;

public class LuaManager : MonoBehaviour {
    private Lua lua;

    void Start() {

        lua = new Lua();

        global::System.Object value = 
        lua.DoFile(""Assets/Resources/LuaScripts/main"");

    }

    public void ExecuteLuaScript(string luaScript) {
        lua.DoString(luaScript);
    }
}
