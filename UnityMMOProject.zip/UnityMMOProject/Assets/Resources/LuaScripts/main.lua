-- Main Lua Script for Unity MMO
print("Lua script initialized.")

-- Example function
function greetPlayer(playerName)
    print("Welcome to the game, " .. playerName .. "!")
end

-- Call the function with a sample player name
greetPlayer("Hero")
