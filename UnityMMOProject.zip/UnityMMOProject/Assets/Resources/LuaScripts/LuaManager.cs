using UnityEngine;
using System.Collections;
using NLua;

public class LuaManager : MonoBehaviour {
    private Lua lua;

    void Start() {
        lua = new Lua();

        // Charger le fichier Lua depuis Resources
        TextAsset luaFile = Resources.Load<TextAsset>("LuaScripts/main");
        if (luaFile != null) {
            lua.DoString(luaFile.text);
            Debug.Log("Lua file loaded successfully.");
        } else {
            Debug.LogError("Lua file not found in Resources/LuaScripts.");
        }
    }

    public void ExecuteLuaScript(string luaScript) {
        lua.DoString(luaScript);
    }
}
